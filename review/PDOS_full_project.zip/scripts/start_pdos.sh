#!/usr/bin/env bash
# scripts/start_pdos.sh — builds the frontend and serves everything from :3000
# The preview gateway on :81 forwards external traffic to local port :3000.
# The Node backend serves the built Vite assets (frontend/dist/) + all /api/* routes.
#
# Usage:
#   bash /home/z/my-project/scripts/start_pdos.sh

set -e
REPO="/home/z/my-project/_PDOS"
LOG_DIR="/home/z/my-project/scripts"
PORT="${PORT:-3000}"
mkdir -p "$LOG_DIR"

# Kill any existing instances
pkill -f "node $REPO/server.js" 2>/dev/null || true
pkill -f "vite" 2>/dev/null || true
sleep 1

# Build frontend (production bundle) — only if dist is stale
if [ ! -f "$REPO/frontend/dist/index.html" ] || [ "$REPO/frontend/src" -nt "$REPO/frontend/dist" ]; then
  echo "[1/2] Building frontend..."
  cd "$REPO/frontend"
  npx vite build > "$LOG_DIR/build.log" 2>&1 || { echo "Build failed. See $LOG_DIR/build.log"; exit 1; }
  echo "  Built → frontend/dist/"
else
  echo "[1/2] Frontend already built, skipping."
fi

# Start backend on port 3000 (where the preview gateway forwards to)
echo "[2/2] Starting backend on :$PORT (serves frontend + API)..."
cd "$REPO"
setsid bash -c "PORT=$PORT node server.js > $LOG_DIR/backend.log 2>&1 &"

sleep 4
echo ""
echo "=== Status ==="
pgrep -af "node $REPO/server.js" | head -1 || echo "  backend NOT running"
echo ""
echo "=== Health check (direct) ==="
echo "GET /            → HTTP $(curl -s -o /dev/null -w '%{http_code}' --max-time 3 http://127.0.0.1:$PORT/)"
echo "GET /api/symbols → $(curl -s --max-time 3 http://127.0.0.1:$PORT/api/symbols)"
echo ""
echo "=== Health check (via gateway on :81) ==="
echo "GET /            → HTTP $(curl -s -o /dev/null -w '%{http_code}' --max-time 3 http://127.0.0.1:81/)"
echo "GET /api/symbols → $(curl -s --max-time 3 http://127.0.0.1:81/api/symbols)"
