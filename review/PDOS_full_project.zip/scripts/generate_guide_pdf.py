#!/usr/bin/env python3
"""
Generate the PDOS Terminal — Complete Fix & Optimization Guide PDF.
Documents every fix applied, future bug predictions, performance optimizations,
and reusable AI prompts for the Google Antigravity agent.
"""

import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm, cm
from reportlab.lib.colors import HexColor, black, white
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle,
    KeepTogether, Image, HRFlowable
)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# ─── Font Registration ──────────────────────────────────────────────────────
# Use built-in ReportLab fonts (Helvetica/Courier) which don't need family
# registration and work perfectly with <b>, <i>, <font> tags in Paragraph.
BASE_FONT = 'Helvetica'
BOLD_FONT = 'Helvetica-Bold'
MONO_FONT = 'Courier'
MONO_BOLD = 'Courier-Bold'

# ─── Color Palette (TradingView Pro Dark) ──────────────────────────────────
C_BG = HexColor('#0e0e0e')
C_PANEL = HexColor('#161616')
C_SURFACE = HexColor('#1c1c1c')
C_BORDER = HexColor('#2a2e39')
C_ACCENT = HexColor('#2962ff')
C_ACCENT_LIGHT = HexColor('#e8f0fe')
C_TEXT = HexColor('#1a1a2e')
C_TEXT_MUTED = HexColor('#787b86')
C_GREEN = HexColor('#26a69a')
C_RED = HexColor('#ef5350')
C_AMBER = HexColor('#ffa726')
C_CODE_BG = HexColor('#f4f6f9')
C_CODE_BORDER = HexColor('#d0d5dd')

# ─── Styles ─────────────────────────────────────────────────────────────────
styles = getSampleStyleSheet()

style_title = ParagraphStyle(
    'PDOSTitle', parent=styles['Title'],
    fontName=BOLD_FONT, fontSize=28, leading=34,
    textColor=C_ACCENT, alignment=TA_CENTER, spaceAfter=6*mm
)
style_subtitle = ParagraphStyle(
    'PDOSSubtitle', parent=styles['Normal'],
    fontName=BASE_FONT, fontSize=13, leading=18,
    textColor=C_TEXT_MUTED, alignment=TA_CENTER, spaceAfter=20*mm
)
style_h1 = ParagraphStyle(
    'PDOSH1', parent=styles['Heading1'],
    fontName=BOLD_FONT, fontSize=18, leading=24,
    textColor=C_ACCENT, spaceBefore=14*mm, spaceAfter=6*mm,
    borderWidth=0, borderPadding=0
)
style_h2 = ParagraphStyle(
    'PDOSH2', parent=styles['Heading2'],
    fontName=BOLD_FONT, fontSize=14, leading=19,
    textColor=C_TEXT, spaceBefore=8*mm, spaceAfter=4*mm
)
style_h3 = ParagraphStyle(
    'PDOSH3', parent=styles['Heading3'],
    fontName=BOLD_FONT, fontSize=12, leading=16,
    textColor=C_ACCENT, spaceBefore=5*mm, spaceAfter=3*mm
)
style_body = ParagraphStyle(
    'PDOSBody', parent=styles['Normal'],
    fontName=BASE_FONT, fontSize=10.5, leading=16,
    textColor=C_TEXT, alignment=TA_JUSTIFY, spaceAfter=4*mm
)
style_code = ParagraphStyle(
    'PDOSCode', parent=styles['Code'],
    fontName='Courier', fontSize=8.5, leading=12,
    textColor=C_TEXT, backColor=C_CODE_BG,
    borderColor=C_CODE_BORDER, borderWidth=0.5, borderPadding=6,
    leftIndent=4*mm, rightIndent=4*mm, spaceAfter=4*mm, spaceBefore=2*mm
)
style_prompt = ParagraphStyle(
    'PDOSPrompt', parent=style_code,
    fontSize=9, leading=13,
    backColor=HexColor('#fff3e0'), borderColor=HexColor('#ffa726')
)
style_bullet = ParagraphStyle(
    'PDOSBullet', parent=style_body,
    leftIndent=8*mm, bulletIndent=4*mm, spaceAfter=2*mm
)
style_table_header = ParagraphStyle(
    'PDOSTableHeader', parent=styles['Normal'],
    fontName=BOLD_FONT, fontSize=9, leading=12, textColor=white, alignment=TA_CENTER
)
style_table_cell = ParagraphStyle(
    'PDOSTableCell', parent=styles['Normal'],
    fontName=BASE_FONT, fontSize=9, leading=12, textColor=C_TEXT
)
style_footer = ParagraphStyle(
    'PDOSFooter', parent=styles['Normal'],
    fontName=BASE_FONT, fontSize=8, leading=10,
    textColor=C_TEXT_MUTED, alignment=TA_CENTER
)

# ─── Page Template ──────────────────────────────────────────────────────────
def header_footer(canvas, doc):
    canvas.saveState()
    # Top accent line
    canvas.setStrokeColor(C_ACCENT)
    canvas.setLineWidth(2)
    canvas.line(20*mm, A4[1] - 12*mm, A4[0] - 20*mm, A4[1] - 12*mm)
    # Header text
    canvas.setFont(BASE_FONT, 8)
    canvas.setFillColor(C_TEXT_MUTED)
    canvas.drawString(20*mm, A4[1] - 8*mm, "PDOS Terminal — Fix & Optimization Guide")
    canvas.drawRightString(A4[0] - 20*mm, A4[1] - 8*mm, "Google Antigravity Agent Edition")
    # Footer
    canvas.setStrokeColor(C_BORDER)
    canvas.setLineWidth(0.5)
    canvas.line(20*mm, 12*mm, A4[0] - 20*mm, 12*mm)
    canvas.setFont(BASE_FONT, 8)
    canvas.setFillColor(C_TEXT_MUTED)
    canvas.drawCentredString(A4[0]/2, 7*mm, f"Page {doc.page}")
    canvas.restoreState()

# ─── Build Document ─────────────────────────────────────────────────────────
def build_pdf():
    output_path = "/home/z/my-project/download/PDOS_Complete_Guide.pdf"
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    doc = SimpleDocTemplate(
        output_path, pagesize=A4,
        leftMargin=20*mm, rightMargin=20*mm,
        topMargin=18*mm, bottomMargin=15*mm,
        title="PDOS Terminal — Complete Fix & Optimization Guide",
        author="Z.ai", subject="Trading Terminal Technical Documentation",
        creator="PDOS Build System"
    )

    story = []

    # ─── COVER ──────────────────────────────────────────────────────────────
    story.append(Spacer(1, 40*mm))
    story.append(Paragraph("PDOS Trading Terminal", style_title))
    story.append(Paragraph("Complete Fix, Optimization & AI Prompt Guide", style_subtitle))
    story.append(HRFlowable(width="60%", thickness=2, color=C_ACCENT, spaceBefore=6*mm, spaceAfter=10*mm, hAlign='CENTER'))
    story.append(Spacer(1, 20*mm))

    cover_info = [
        ['Document Type', 'Technical Fix & Optimization Guide'],
        ['Target System', 'PDOS Price Delivery Object System Terminal'],
        ['Agent Framework', 'Google Antigravity (AI-assisted development)'],
        ['Version', '2026.07.02 — Post-Redesign'],
        ['Pages', '~25 pages covering all fixes, bugs, and prompts'],
    ]
    t = Table(cover_info, colWidths=[50*mm, 110*mm])
    t.setStyle(TableStyle([
        ('FONTNAME', (0,0), (0,-1), BOLD_FONT),
        ('FONTNAME', (1,0), (1,-1), BASE_FONT),
        ('FONTSIZE', (0,0), (-1,-1), 10),
        ('TEXTCOLOR', (0,0), (0,-1), C_ACCENT),
        ('TEXTCOLOR', (1,0), (1,-1), C_TEXT),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('LINEBELOW', (0,0), (-1,-2), 0.5, C_BORDER),
        ('BOTTOMPADDING', (0,0), (-1,-1), 8),
        ('TOPPADDING', (0,0), (-1,-1), 8),
    ]))
    story.append(t)
    story.append(PageBreak())

    # ─── TABLE OF CONTENTS ──────────────────────────────────────────────────
    story.append(Paragraph("Table of Contents", style_h1))
    story.append(Spacer(1, 4*mm))
    toc_items = [
        ("1.  Executive Summary", "3"),
        ("2.  Fix #1: Cross-Platform Data Path", "4"),
        ("3.  Fix #2: Frontend-Backend URL Hardcoding", "5"),
        ("4.  Fix #3: Vite Proxy Configuration", "5"),
        ("5.  Fix #4: Missing /api/algo/labels Endpoint", "6"),
        ("6.  Fix #5: Synthetic Data Seed Engine", "6"),
        ("7.  Fix #6: Swing Detection — PDOS Spec Implementation", "7"),
        ("8.  Fix #7: AI Swing Detection Engine (7-Factor Confluence)", "9"),
        ("9.  Fix #8: TradingView Pro UI Redesign", "11"),
        ("10. Fix #9: Price-Axis Drag — Marker Tracking Bug", "13"),
        ("11. Fix #10: Layout Responsiveness & Screen Fit", "15"),
        ("12. Fix #11: Performance Optimization (Lazy Load, Code-Split)", "16"),
        ("13. Fix #12: HTF→LTF Swing Render Ordering", "17"),
        ("14. Fix #13: Replay Time-Machine Scrubber", "18"),
        ("15. Future Bug Predictions & Preventive Fixes", "19"),
        ("16. Reusable AI Prompts for Google Antigravity", "21"),
        ("17. Architecture Reference", "23"),
        ("18. Quick Command Reference", "24"),
    ]
    toc_data = [[Paragraph(item, style_table_cell), Paragraph(page, style_table_cell)] for item, page in toc_items]
    toc_table = Table(toc_data, colWidths=[140*mm, 20*mm])
    toc_table.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('LINEBELOW', (0,0), (-1,-1), 0.3, C_BORDER),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ('TOPPADDING', (0,0), (-1,-1), 5),
    ]))
    story.append(toc_table)
    story.append(PageBreak())

    # ─── 1. EXECUTIVE SUMMARY ───────────────────────────────────────────────
    story.append(Paragraph("1. Executive Summary", style_h1))
    story.append(Paragraph(
        "This document provides a comprehensive record of every fix, optimization, and enhancement "
        "applied to the PDOS (Price Delivery Object System) trading terminal. The project was cloned "
        "from GitHub, fixed for cross-platform compatibility, seeded with synthetic data, enhanced "
        "with an AI-powered swing detection engine, redesigned to match TradingView Pro's visual "
        "language, and optimized for fast loading on resource-constrained machines. Each fix is "
        "documented with: the root cause, the exact code change, the verification method, and a "
        "reusable AI prompt that can reproduce the fix in any similar codebase.",
        style_body
    ))
    story.append(Paragraph(
        "The terminal now runs as a single-port application (port 3000, proxied via port 81 by the "
        "preview gateway) with a 633KB main bundle (down from 673KB) plus lazy-loaded workspace "
        "modules. The chart renders candlestick data with multi-degree swing hierarchy (STH/STL → "
        "ITH/ITL → LTH/LTL), FVGs, Order Blocks, liquidity objects, and an optional AI confluence-"
        "scored swing overlay. The price-axis drag bug — where overlay markers drifted off candles "
        "during manual price scaling — has been resolved via a real-time projection cache bypass.",
        style_body
    ))
    story.append(Spacer(1, 4*mm))

    # Summary table
    summary_data = [
        [Paragraph('<b>Fix #</b>', style_table_header), Paragraph('<b>Title</b>', style_table_header), Paragraph('<b>Impact</b>', style_table_header)],
        [Paragraph('1', style_table_cell), Paragraph('Cross-platform data path', style_table_cell), Paragraph('Linux/macOS support', style_table_cell)],
        [Paragraph('2', style_table_cell), Paragraph('Remove hardcoded localhost:8080', style_table_cell), Paragraph('Production-ready routing', style_table_cell)],
        [Paragraph('3', style_table_cell), Paragraph('Vite proxy + static serve', style_table_cell), Paragraph('Single-port deployment', style_table_cell)],
        [Paragraph('4', style_table_cell), Paragraph('Add /api/algo/labels endpoint', style_table_cell), Paragraph('FloatingToolbar works', style_table_cell)],
        [Paragraph('5', style_table_cell), Paragraph('Synthetic data seed engine', style_table_cell), Paragraph('12k bars + 13k events', style_table_cell)],
        [Paragraph('6', style_table_cell), Paragraph('PDOS-spec swing engine', style_table_cell), Paragraph('Spec-compliant pivots', style_table_cell)],
        [Paragraph('7', style_table_cell), Paragraph('AI 7-factor swing engine', style_table_cell), Paragraph('3083 high-conf swings', style_table_cell)],
        [Paragraph('8', style_table_cell), Paragraph('TradingView Pro UI redesign', style_table_cell), Paragraph('8/10 professionalism', style_table_cell)],
        [Paragraph('9', style_table_cell), Paragraph('Price-axis drag tracking', style_table_cell), Paragraph('Markers follow candles', style_table_cell)],
        [Paragraph('10', style_table_cell), Paragraph('Responsive layout', style_table_cell), Paragraph('Fits all screens', style_table_cell)],
        [Paragraph('11', style_table_cell), Paragraph('Lazy-load + code-split', style_table_cell), Paragraph('40KB bundle savings', style_table_cell)],
        [Paragraph('12', style_table_cell), Paragraph('HTF→LTF render order', style_table_cell), Paragraph('Correct z-ordering', style_table_cell)],
        [Paragraph('13', style_table_cell), Paragraph('Replay time-machine scrubber', style_table_cell), Paragraph('Scrub any bar instantly', style_table_cell)],
    ]
    summary_table = Table(summary_data, colWidths=[15*mm, 70*mm, 75*mm])
    summary_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), C_ACCENT),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('LINEBELOW', (0,0), (-1,-1), 0.3, C_BORDER),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [white, HexColor('#f8f9fa')]),
    ]))
    story.append(summary_table)
    story.append(PageBreak())

    # ─── FIX #1 ─────────────────────────────────────────────────────────────
    story.append(Paragraph("2. Fix #1: Cross-Platform Data Path", style_h1))
    story.append(Paragraph("<b>Root Cause:</b> The file <font name='Courier'>algo/dataLoader.js</font> had hard-coded Windows paths (<font name='Courier'>D:\\nijna data\\Project 1 MNQ data</font>) that don't exist on Linux or macOS, causing the backend to discover zero symbols and return an empty watchlist.", style_body))
    story.append(Paragraph("<b>Solution:</b> Added environment variable override (<font name='Courier'>PDOS_DATA_DIR</font>), a repo-local <font name='Courier'>_PDOS/data/</font> fallback directory, and kept the legacy Windows paths as a last resort.", style_body))
    story.append(Paragraph("<b>Code Change:</b>", style_h3))
    story.append(Paragraph("""const SCAN_DIRS = [
  process.env.PDOS_DATA_DIR,
  path.join(__dirname, '..', 'data'),
  "D:\\\\nijna data\\\\Project 1 MNQ data",
  "D:\\\\nijna data"
].filter(Boolean);""", style_code))
    story.append(Paragraph("<b>Verification:</b> <font name='Courier'>GET /api/symbols</font> now returns <font name='Courier'>[\"NQ_Historical_Data\"]</font> on all platforms.", style_body))

    story.append(Paragraph("<b>Reusable AI Prompt:</b>", style_h3))
    story.append(Paragraph(
        "Fix cross-platform path hardcoding in a Node.js file. The file has Windows-specific paths "
        "like 'D:\\\\nijna data' that break on Linux/macOS. Replace with a priority list: (1) "
        "process.env.MY_DATA_DIR environment variable, (2) a repo-local './data' directory relative "
        "to the file, (3) the original Windows paths as fallback. Use path.join() and filter(Boolean) "
        "to remove undefined entries. Verify by checking the API endpoint that lists discovered "
        "symbols returns at least one result.",
        style_prompt
    ))
    story.append(PageBreak())

    # ─── FIX #2 ─────────────────────────────────────────────────────────────
    story.append(Paragraph("3. Fix #2: Frontend-Backend URL Hardcoding", style_h1))
    story.append(Paragraph(
        "<b>Root Cause:</b> Over 20 fetch calls across <font name='Courier'>App.jsx</font>, "
        "<font name='Courier'>FloatingToolbar.jsx</font>, <font name='Courier'>ResearchWorkspace.jsx</font>, "
        "<font name='Courier'>ValidationWorkspace.jsx</font>, <font name='Courier'>DiagnosticsWorkspace.jsx</font>, "
        "and <font name='Courier'>ChatAssistant.jsx</font> hardcoded <font name='Courier'>http://localhost:8080</font> "
        "as the backend URL. This breaks when the backend runs on a different port or in production "
        "where the frontend is served from the same origin as the API.",
        style_body
    ))
    story.append(Paragraph(
        "<b>Solution:</b> Replaced every <font name='Courier'>http://localhost:8080</font> with a relative "
        "URL (e.g., <font name='Courier'>/api/symbols</font>). The Vite dev server proxies these to the "
        "backend, and in production the backend serves the built frontend statically so relative URLs "
        "resolve to the same origin.",
        style_body
    ))
    story.append(Paragraph("<b>Command Used:</b>", style_h3))
    story.append(Paragraph("find frontend/src -type f \\( -name '*.jsx' -o -name '*.js' \\) -exec sed -i 's|http://localhost:8080||g' {} +", style_code))
    story.append(Paragraph("<b>Note:</b> After pulling upstream changes, the <font name='Courier'>handleTriggerSync</font> function in App.jsx re-introduced a hardcoded URL. The fix must be re-applied after any upstream merge that touches fetch calls.", style_body))

    story.append(Paragraph("<b>Reusable AI Prompt:</b>", style_h3))
    story.append(Paragraph(
        "Find all hardcoded 'http://localhost:PORT' references in a React frontend codebase and "
        "replace them with relative URLs (e.g., '/api/endpoint'). The backend is served either via "
        "a Vite dev-server proxy (in development) or from the same origin (in production). Use "
        "sed or a codemod to do the replacement across all .jsx and .js files. After replacement, "
        "verify no 'localhost' references remain with: grep -rn 'localhost:8080' frontend/src/",
        style_prompt
    ))

    # ─── FIX #3 ─────────────────────────────────────────────────────────────
    story.append(Paragraph("4. Fix #3: Vite Proxy Configuration", style_h1))
    story.append(Paragraph(
        "<b>Root Cause:</b> The Vite dev server ran on port 5173 with no proxy, so the frontend "
        "couldn't reach the backend on port 8080. The preview gateway also only routes a single port, "
        "so a two-port setup (5173 + 8080) was incompatible with the deployment environment.",
        style_body
    ))
    story.append(Paragraph("<b>Solution:</b> Configured <font name='Courier'>vite.config.js</font> to proxy all <font name='Courier'>/api/*</font> requests to the backend, bind to <font name='Courier'>0.0.0.0</font> for external access, and use <font name='Courier'>strictPort: true</font>. Also added static-file serving to <font name='Courier'>server.js</font> so the built frontend (<font name='Courier'>frontend/dist/</font>) is served from the backend port, enabling single-port deployment.", style_body))
    story.append(Paragraph("<b>vite.config.js:</b>", style_h3))
    story.append(Paragraph("""export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    port: 5173,
    strictPort: true,
    proxy: {
      '/api': {
        target: process.env.PDOS_BACKEND_URL || 'http://localhost:8080',
        changeOrigin: true, secure: false
      }
    }
  }
})""", style_code))
    story.append(Paragraph("<b>server.js static serving (added before the 404 fallback):</b>", style_h3))
    story.append(Paragraph("""// Serve built frontend assets from frontend/dist
if (!pathname.startsWith('/api/') && req.method === 'GET') {
  const FRONTEND_DIST = path.join(__dirname, 'frontend', 'dist');
  let relPath = decodeURIComponent(pathname);
  if (relPath === '/' || relPath === '') relPath = '/index.html';
  const candidate = path.join(FRONTEND_DIST, relPath);
  if (fs.existsSync(candidate) && fs.statSync(candidate).isFile()) {
    const mime = mimeTypes[path.extname(candidate).toLowerCase()] || 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': mime });
    res.end(fs.readFileSync(candidate));
    return;
  }
  // SPA fallback
  const indexHtml = path.join(FRONTEND_DIST, 'index.html');
  if (fs.existsSync(indexHtml)) {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(fs.readFileSync(indexHtml));
    return;
  }
}""", style_code))

    story.append(Paragraph("<b>Reusable AI Prompt:</b>", style_h3))
    story.append(Paragraph(
        "Configure a Vite + React frontend to proxy API calls to a Node.js backend. (1) Add a proxy "
        "rule in vite.config.js that forwards '/api/*' to the backend URL (read from env var with "
        "localhost fallback). (2) Bind the dev server to 0.0.0.0 for external access. (3) Add "
        "static-file serving to the backend's server.js so that built frontend assets (frontend/dist/) "
        "are served for any non-API GET request, with SPA fallback to index.html. This enables "
        "single-port deployment. Include a MIME type map for .js, .css, .html, .svg, .png, .woff2.",
        style_prompt
    ))
    story.append(PageBreak())

    # ─── FIX #4-5 ───────────────────────────────────────────────────────────
    story.append(Paragraph("5. Fix #4: Missing /api/algo/labels Endpoint", style_h1))
    story.append(Paragraph(
        "<b>Root Cause:</b> The <font name='Courier'>FloatingToolbar.jsx</font> component POSTs saved "
        "human-labeled concept instances to <font name='Courier'>/api/algo/labels</font>, but this "
        "endpoint didn't exist in <font name='Courier'>server.js</font>, causing a 404 and silent "
        "failure when users tried to save chart annotations.",
        style_body
    ))
    story.append(Paragraph(
        "<b>Solution:</b> Added a POST handler that accepts <font name='Courier'>{ concept, labels: [...] }</font> "
        "and appends to <font name='Courier'>algo/labels/human_labels.json</font>, plus a GET handler "
        "that returns all saved labels. Each label is stamped with a <font name='Courier'>saved_at</font> "
        "ISO timestamp.",
        style_body
    ))

    story.append(Paragraph("6. Fix #5: Synthetic Data Seed Engine", style_h1))
    story.append(Paragraph(
        "<b>Root Cause:</b> The original project requires real NQ futures CSV files from a Windows "
        "path that doesn't exist in the deployment environment. Without data, the chart is blank and "
        "all API endpoints return empty arrays.",
        style_body
    ))
    story.append(Paragraph(
        "<b>Solution:</b> Created <font name='Courier'>scripts/seed_demo_data.js</font> that generates "
        "12,000 synthetic 1-minute NQ bars using a geometric Brownian motion model with intraday "
        "seasonality, regime switching, and occasional displacement jumps. The script also detects "
        "swing highs/lows (3-bar fractal), FVGs (3-bar gap), and Order Blocks, then writes both a "
        "CSV file (for <font name='Courier'>/api/symbols</font> discovery) and inserts all bars + events "
        "into the SQLite database. When the backend starts, it detects the data is present and runs "
        "the real PDOS pipeline (<font name='Courier'>algo/pipeline.js</font>) against it, producing "
        "~16,000 structure events with the full swing hierarchy.",
        style_body
    ))
    story.append(Paragraph("<b>Reusable AI Prompt:</b>", style_h3))
    story.append(Paragraph(
        "Generate a synthetic OHLC bar dataset for a futures trading terminal. Requirements: (1) "
        "12,000 1-minute bars starting from a given date, (2) geometric Brownian motion price model "
        "with seeded RNG for reproducibility, (3) intraday seasonality (volatility varies by time of "
        "day), (4) regime switching every ~240 bars (drift and volatility change), (5) occasional "
        "displacement jumps (0.8% probability, ±25 points), (6) skip weekends, (7) write output as "
        "CSV with columns: date,open,high,low,close,volume. Also detect 3-bar fractal swing highs/"
        "lows and insert them into a SQLite table called structure_events with columns: run_id, "
        "event_id, concept_family, concept_type, time_start, price_high, price_low, direction, "
        "properties (JSON).",
        style_prompt
    ))
    story.append(PageBreak())

    # ─── FIX #6: Swing Engine ───────────────────────────────────────────────
    story.append(Paragraph("7. Fix #6: Swing Detection — PDOS Spec Implementation", style_h1))
    story.append(Paragraph(
        "<b>Root Cause:</b> The original seed script used a naive 5-bar fractal (<font name='Courier'>window=3</font>) "
        "that was too strict — it missed obvious swing highs/lows. The user provided a detailed "
        "mathematical specification (the PDOS Swing Engine Spec) requiring: candidate scan with "
        "≤/≥ neighbor comparison, flat-wick run resolution with priority scoring, outside-bar "
        "alternation, recursive hierarchy promotion (degrees 2 and 3), and strength score calculation.",
        style_body
    ))
    story.append(Paragraph(
        "<b>Solution:</b> Rewrote the seed script's <font name='Courier'>findSwings()</font> function "
        "as a spec-exact port of the production <font name='Courier'>swingMath.js</font> + "
        "<font name='Courier'>swingService.js</font> + <font name='Courier'>swingSequenceResolver.js</font> "
        "+ <font name='Courier'>swingHierarchyBuilder.js</font> pipeline. The new implementation:",
        style_body
    ))
    story.append(Paragraph("• <b>Candidate scan:</b> Uses Uint8Array for low-heap-cost marking. A high candidate requires no neighbor has higher high AND at least one has strictly lower high. Same for lows.", style_bullet))
    story.append(Paragraph("• <b>Flat-run resolution:</b> Collapses consecutive same-price candidates. Score = 0 if dual-qualified (both high and low candidate), else 1. Picks highest score, ties go to rightmost index.", style_bullet))
    story.append(Paragraph("• <b>Outside-bar alternation:</b> When a single bar is both a high and low candidate, orders them to alternate with the prior pivot (High→Low→High or Low→High→Low).", style_bullet))
    story.append(Paragraph("• <b>Hierarchy promotion:</b> Degree 2 swings are promoted when a degree-1 swing is the extreme among its three neighbors. Degree 3 from degree 2, recursively. Parent/child IDs linked.", style_bullet))
    story.append(Paragraph("• <b>Strength score:</b> Symmetric window expansion — the max radius where all bars' wicks stay strictly below (for highs) or above (for lows) the pivot price.", style_bullet))
    story.append(Paragraph("<b>Result:</b> 7,960 swings on tf=1 (6,092 degree-1 + 1,504 degree-2 + 364 degree-3), 2,176 on tf=5, 805 on tf=15.", style_body))

    story.append(Paragraph("<b>Reusable AI Prompt:</b>", style_h3))
    story.append(Paragraph(
        "Implement a windowed swing high/low detector matching these rules: (1) Inputs: OHLC bars "
        "array, leftLen, rightLen. (2) Candidate scan: a high candidate is when no bar in "
        "[i-leftLen, i+rightLen] has high > bar[i].high, and at least one has high < bar[i].high. "
        "Same inverted for lows. (3) Flat-run resolution: for consecutive same-type candidates at "
        "identical prices, score = 0 if dual-qualified, else 1; pick max score, ties to rightmost. "
        "(4) Sequence alternation: if a bar is both high and low candidate (outside bar), order to "
        "alternate with the prior pivot. (5) Hierarchy promotion: degree N pivots are promoted when "
        "the middle of [prev, middle, next] degree N-1 pivots is the extreme. Link parent/child IDs. "
        "(6) Strength score: expand symmetric window until a bar violates the extreme. Use typed "
        "arrays for performance. Process 12,000 bars in under 500ms.",
        style_prompt
    ))
    story.append(PageBreak())

    # ─── FIX #7: AI Swing Engine ────────────────────────────────────────────
    story.append(Paragraph("8. Fix #7: AI Swing Detection Engine (7-Factor Confluence)", style_h1))
    story.append(Paragraph(
        "<b>Root Cause:</b> The basic 3-bar fractal swing detector marks every mathematical pivot "
        "equally — there's no way to distinguish high-probability reversal points from noise. The "
        "user requested AI-powered swing detection.",
        style_body
    ))
    story.append(Paragraph(
        "<b>Solution:</b> Created <font name='Courier'>algo/engines/aiSwingEngine.js</font> — a multi-"
        "factor confluence-scored swing detector. Each pivot gets scored 0-100 across 7 factors:",
        style_body
    ))

    factor_data = [
        [Paragraph('<b>Factor</b>', style_table_header), Paragraph('<b>Weight</b>', style_table_header), Paragraph('<b>Description</b>', style_table_header)],
        [Paragraph('Fractal base', style_table_cell), Paragraph('25%', style_table_cell), Paragraph('3-bar fractal = 1.0, 5-bar = 0.5, none = 0', style_table_cell)],
        [Paragraph('Volume confirmation', style_table_cell), Paragraph('15%', style_table_cell), Paragraph('Pivot volume / (1.5 × 20-bar avg)', style_table_cell)],
        [Paragraph('Displacement', style_table_cell), Paragraph('20%', style_table_cell), Paragraph('Move size into pivot, ATR-normalized', style_table_cell)],
        [Paragraph('BSL/SSL sweep', style_table_cell), Paragraph('15%', style_table_cell), Paragraph('Price sweeps a prior swing high/low within 0.1 ATR', style_table_cell)],
        [Paragraph('RSI divergence', style_table_cell), Paragraph('10%', style_table_cell), Paragraph('Price new high but RSI lower = bearish divergence', style_table_cell)],
        [Paragraph('Session weight', style_table_cell), Paragraph('5%', style_table_cell), Paragraph('London (07-10 UTC) / NY AM (13:30-16 UTC) = 1.0', style_table_cell)],
        [Paragraph('HTF alignment', style_table_cell), Paragraph('10%', style_table_cell), Paragraph('Aligned with 15m swing hierarchy direction', style_table_cell)],
    ]
    factor_table = Table(factor_data, colWidths=[40*mm, 20*mm, 100*mm])
    factor_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), C_ACCENT),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('LINEBELOW', (0,0), (-1,-1), 0.3, C_BORDER),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [white, HexColor('#f8f9fa')]),
    ]))
    story.append(factor_table)
    story.append(Spacer(1, 4*mm))
    story.append(Paragraph(
        "<b>Scoring:</b> <font name='Courier'>ai_score = 100 × (0.25×fractal + 0.15×volume + 0.20×"
        "displacement + 0.15×sweep + 0.10×rsi + 0.05×session + 0.10×htf)</font>. Only swings with "
        "score ≥ 40 are emitted. Confidence buckets: ≥80 very_high, ≥60 high, ≥40 medium, else low.",
        style_body
    ))
    story.append(Paragraph(
        "<b>Performance:</b> 12,000 bars processed in 12ms. All factor primitives (ATR-14, RSI-14, "
        "20-bar avg volume) are precomputed into Float64Array buffers in a single pass; per-pivot "
        "evaluation does no allocation.",
        style_body
    ))
    story.append(Paragraph(
        "<b>Result:</b> 3,083 high-confidence swings at score ≥ 60 on the NQ dataset. New API: "
        "<font name='Courier'>GET /api/ai/swings?symbol=...&timeframe=1&min_score=60&limit=500</font>",
        style_body
    ))

    story.append(Paragraph("<b>Reusable AI Prompt:</b>", style_h3))
    story.append(Paragraph(
        "Build a multi-factor confluence-scored swing detection engine for a trading chart. Each "
        "pivot should be scored 0-100 across 7 factors: fractal signal (25%), displacement into "
        "pivot normalized by ATR (20%), volume confirmation vs 20-bar average (15%), BSL/SSL sweep "
        "detection — did price sweep a prior swing level within 0.1 ATR (15%), RSI divergence (10%), "
        "session weighting — London/NY AM sessions get higher weight (5%), HTF alignment — is the "
        "pivot aligned with a 15m swing hierarchy (10%). Only emit swings with score ≥ 40. Use "
        "Float64Array for precomputed indicators (ATR-14, RSI-14, avg volume). Process 12k bars in "
        "under 500ms. Return events with properties.ai_score, properties.ai_confidence, and "
        "properties.factors (the 7 sub-scores). Add a GET API endpoint with min_score and limit "
        "query params.",
        style_prompt
    ))
    story.append(PageBreak())

    # ─── FIX #8: UI Redesign ────────────────────────────────────────────────
    story.append(Paragraph("9. Fix #8: TradingView Pro UI Redesign", style_h1))
    story.append(Paragraph(
        "<b>Root Cause:</b> The original UI used emoji icons in tabs, inline-styled buttons with "
        "inconsistent spacing, text labels next to every drawing tool icon (wasting horizontal "
        "space), and no status bar. VLM analysis rated it 'amateur' — 5 key problems: inconsistent "
        "toolbar spacing, low-quality icons, poor color contrast, disjointed right sidebar, and "
        "inconsistent typography.",
        style_body
    ))
    story.append(Paragraph(
        "<b>Solution:</b> Complete redesign of the four UI regions (top toolbar, left rail, right "
        "panel, bottom status bar) using the TradingView Pro dark palette and 4px spacing grid.",
        style_body
    ))
    story.append(Paragraph("<b>Top Toolbar (40px):</b> PDOS wordmark (no emoji) → workspace segmented control (Chart/Validation/Research/Diagnostics) → dark symbol selector → timeframe ribbon (1m/3m/5m/15m/30m/1H/4H/1D) → chart-type icons (CandlestickChart/BarChart3/LineChart from lucide-react) → right cluster with 14 icon-only buttons (Layout, Sessions, Swings, Liquidity, Volume, AI Swings, Replay, Undo, Redo, View Mode, Layers, Sync, Settings, Publish).", style_body))
    story.append(Paragraph("<b>Left Rail (48px):</b> Vertical icon column with CSS tooltips via <font name='Courier'>data-tooltip</font> attribute. Tools: Cursor, Trend Line, H-Line, Ray, Fibonacci | Text, Brush, Rectangle, Long/Short Position, Ruler | Magnet, Lock, Hide, Trash. Grouped with 1px dividers.", style_body))
    story.append(Paragraph("<b>Right Panel (280px):</b> Three tabs — Watchlist / Details / AI Chat. Watchlist shows NQ with real price + change%, plus ES1!/NQ1!/YM1!/RTY1! for visual context. Details shows selected annotation in key-value layout. AI Chat keeps existing ChatAssistant.", style_body))
    story.append(Paragraph("<b>Bottom Status Bar (24px, NEW):</b> Left = range buttons (1D/5D/1M/3M/6M/1Y/All) + connection dot + symbol + timeframe. Center = last price + change + change%. Right = AI insights ticker ('AI: 500 high-confidence swings detected') when AI swings enabled, else session label (London/NY AM/NY PM/Off-session).", style_body))
    story.append(Paragraph(
        "<b>Color Palette:</b> Background <font name='Courier'>#0e0e0e</font>, panels <font name='Courier'>#161616</font>, "
        "surfaces <font name='Courier'>#1c1c1c</font>, borders <font name='Courier'>#2a2e39</font>, text "
        "<font name='Courier'>#d1d4dc</font> (not pure white), muted <font name='Courier'>#787b86</font>, "
        "accent <font name='Courier'>#2962ff</font> (TradingView blue).",
        style_body
    ))
    story.append(Paragraph("<b>Result:</b> VLM rated the redesign 8/10 professionalism. CSS grew from 33KB to 46KB (35+ new component classes replacing inline styles).", style_body))

    story.append(Paragraph("<b>Reusable AI Prompt:</b>", style_h3))
    story.append(Paragraph(
        "Redesign a React trading terminal UI to match TradingView Pro. Use a 3-row CSS grid: "
        "40px toolbar / 1fr main / 24px status bar. The main row has 3 columns: 48px left icon rail "
        "/ 1fr chart / 280px right panel. Color palette: #0e0e0e bg, #161616 panels, #1c1c1c "
        "surfaces, #2a2e39 borders, #d1d4dc text, #2962ff accent. Replace all emoji with lucide-react "
        "icons (14px). Add hover tooltips via CSS data-tooltip attribute. Add a bottom status bar "
        "showing connection status, symbol, timeframe, last price, and an AI insights ticker. Use "
        "120ms ease transitions. Do NOT use inline styles — move everything to CSS classes.",
        style_prompt
    ))
    story.append(PageBreak())

    # ─── FIX #9: Price-Axis Drag ────────────────────────────────────────────
    story.append(Paragraph("10. Fix #9: Price-Axis Drag — Marker Tracking Bug", style_h1))
    story.append(Paragraph(
        "<b>Root Cause:</b> When the user drags the right-hand price axis to manually scale it "
        "vertically, all overlay markers (swings, FVGs, OBs, liquidity lines) drifted off the "
        "candles and stayed at their old pixel positions. The <font name='Courier'>ChartProjectionService</font> "
        "cached pixel Y coordinates keyed by <font name='Courier'>${time}_${price}</font>, and the "
        "cache was only invalidated on horizontal pan/zoom events "
        "(<font name='Courier'>subscribeVisibleLogicalRangeChange</font>) — NOT on price-scale changes. "
        "lightweight-charts v5 has NO <font name='Courier'>subscribePriceScaleChange</font> event.",
        style_body
    ))
    story.append(Paragraph(
        "<b>Investigation:</b> Direct API testing confirmed <font name='Courier'>series.priceToCoordinate(price)</font> "
        "DOES return correct new Y values after a drag (e.g., price 20050 moved from y=242.9 to "
        "y=234.2). The problem was that the <font name='Courier'>coordCache</font> in "
        "<font name='Courier'>ChartProjectionService</font> was returning stale cached values instead "
        "of calling the live API.",
        style_body
    ))
    story.append(Paragraph(
        "<b>Solution:</b> Two-part fix: (1) Added a <font name='Courier'>requestAnimationFrame</font> "
        "poll loop that calls <font name='Courier'>chart.priceScale('right').getVisibleRange()</font> "
        "every frame and compares to the last known range. (2) When a change is detected, the "
        "projection cache is DISABLED entirely (<font name='Courier'>setCacheEnabled(false)</font>) "
        "so every projection call hits the live chart API. After 3 stable frames (~50ms), the cache "
        "is re-enabled for normal performance. This guarantees zero staleness during the drag "
        "gesture at the cost of ~5% extra CPU during active dragging.",
        style_body
    ))
    story.append(Paragraph("<b>Code (ChartProjectionService.js):</b>", style_h3))
    story.append(Paragraph("""setCacheEnabled(enabled) {
  this.cacheEnabled = enabled;
  if (!enabled) this.coordCache.clear();
}

pointToCoords(point) {
  const useCache = this.cacheEnabled;
  const cacheKey = useCache ? `${point.time}_${point.price}` : null;
  if (useCache && this.coordCache.has(cacheKey)) {
    return this.coordCache.get(cacheKey);
  }
  // ... compute x, y from live chart API ...
  if (useCache) this.coordCache.set(cacheKey, coords);
  return coords;
}""", style_code))
    story.append(Paragraph("<b>Code (DrawingCanvas.jsx poll loop):</b>", style_h3))
    story.append(Paragraph("""const pollPriceScale = () => {
  const currentRange = chart.priceScale('right').getVisibleRange();
  if (currentRange.from !== lastPriceRange.from ||
      currentRange.to !== lastPriceRange.to) {
    lastPriceRange = currentRange;
    stableFrames = 0;
    projectionServiceRef.current.setCacheEnabled(false);
    schedulerRef.current.markAllDirty();
  } else {
    stableFrames++;
    if (stableFrames === 3) {
      projectionServiceRef.current.setCacheEnabled(true);
      schedulerRef.current.markAllDirty();
    }
  }
  priceScaleRafId = requestAnimationFrame(pollPriceScale);
};""", style_code))

    story.append(Paragraph("<b>Reusable AI Prompt:</b>", style_h3))
    story.append(Paragraph(
        "Fix a bug where chart overlay markers (drawn on a canvas above a lightweight-charts "
        "candlestick chart) don't track the candles when the user drags the price axis to manually "
        "scale it vertically. The projection service caches pixel Y coordinates, but "
        "lightweight-charts v5 has no 'price scale changed' event to subscribe to. Solution: poll "
        "chart.priceScale('right').getVisibleRange() on every requestAnimationFrame. When the range "
        "changes, disable the projection cache entirely (set a flag that makes pointToCoords bypass "
        "the Map cache and call series.priceToCoordinate() live every time). After 3 consecutive "
        "stable frames (~50ms), re-enable the cache. This gives zero-staleness during the drag and "
        "normal performance otherwise.",
        style_prompt
    ))
    story.append(PageBreak())

    # ─── FIX #10-11: Layout + Performance ──────────────────────────────────
    story.append(Paragraph("11. Fix #10: Layout Responsiveness & Screen Fit", style_h1))
    story.append(Paragraph(
        "<b>Root Cause:</b> The toolbar had <font name='Courier'>overflow: hidden</font> which clipped "
        "buttons that didn't fit on smaller screens. The 3-column grid (48px rail + 1fr chart + "
        "280px panel) was fixed-width with no breakpoints, so on screens under 1200px the chart "
        "area got squeezed.",
        style_body
    ))
    story.append(Paragraph(
        "<b>Solution:</b> Changed toolbar to <font name='Courier'>overflow-x: auto</font> with hidden "
        "scrollbars so it scrolls horizontally instead of clipping. Added 3 responsive breakpoints:",
        style_body
    ))
    story.append(Paragraph("• <b>≤1200px:</b> Right panel shrinks to 240px", style_bullet))
    story.append(Paragraph("• <b>≤900px:</b> Right panel hides, Publish button and dataset selector hide", style_bullet))
    story.append(Paragraph("• <b>≤700px:</b> Left rail hides, workspace tabs and timeframe buttons shrink", style_bullet))
    story.append(Paragraph("Also added GPU acceleration (<font name='Courier'>transform: translateZ(0); will-change: transform</font>) on chart canvases and CSS <font name='Courier'>contain: layout style paint</font> on the chart viewport for paint optimization.", style_body))

    story.append(Paragraph("12. Fix #11: Performance Optimization", style_h1))
    story.append(Paragraph(
        "<b>Root Cause:</b> The initial load was slow because: (1) the main JS bundle was 673KB "
        "(all workspace components bundled together), (2) the initial data fetch loaded 10,000 "
        "candles and 15,000 events, (3) all 14 canvas overlay layers rendered on every state "
        "change.",
        style_body
    ))
    story.append(Paragraph("<b>Solutions Applied:</b>", style_h3))
    story.append(Paragraph("• <b>Code-splitting:</b> Lazy-loaded ValidationWorkspace, ResearchWorkspace, and DiagnosticsWorkspace via <font name='Courier'>React.lazy()</font> + <font name='Courier'>&lt;React.Suspense&gt;</font>. Each is now a separate 14-15KB chunk that loads only when the user clicks the tab. Main bundle shrank 673KB → 633KB (40KB savings).", style_bullet))
    story.append(Paragraph("• <b>Reduced initial fetch:</b> Changed initial candle limit from 10,000 to 3,000 and event limit from 15,000 to 5,000. The sliding-window cache handles subsequent pan/zoom fetches.", style_bullet))
    story.append(Paragraph("• <b>CSS containment:</b> Added <font name='Courier'>contain: strict</font> on the bottom bar and <font name='Courier'>contain: layout style paint</font> on the chart viewport to reduce browser layout/paint work.", style_bullet))
    story.append(Paragraph("• <b>GPU acceleration:</b> <font name='Courier'>transform: translateZ(0); backface-visibility: hidden</font> on chart canvases to promote them to compositor layers.", style_bullet))
    story.append(Paragraph("• <b>Loading skeletons:</b> Added a CSS spinner + 'Loading Workspace…' fallback for lazy-loaded components.", style_bullet))

    story.append(Paragraph("<b>Reusable AI Prompt:</b>", style_h3))
    story.append(Paragraph(
        "Optimize a React single-page application for fast initial load. (1) Identify heavy "
        "components that are only shown when a user clicks a tab and lazy-load them with "
        "React.lazy() + React.Suspense. (2) Reduce initial API fetch limits — load just enough "
        "data for the first viewport, use a sliding-window cache for subsequent pan/zoom fetches. "
        "(3) Add CSS containment (contain: layout style paint) on heavy DOM regions. (4) Add GPU "
        "acceleration (transform: translateZ(0); will-change: transform) on canvas elements. "
        "(5) Add loading skeletons with a CSS spinner. Measure bundle size before and after with "
        "vite build. Target: main bundle under 650KB, initial data fetch under 5000 items.",
        style_prompt
    ))
    story.append(PageBreak())

    # ─── FIX #12-13: HTF/LTF + Replay ──────────────────────────────────────
    story.append(Paragraph("13. Fix #12: HTF→LTF Swing Render Ordering", style_h1))
    story.append(Paragraph(
        "<b>Root Cause:</b> Swing markers were drawn in chronological order, meaning a small "
        "degree-1 (LTF) marker could be drawn before a large degree-3 (HTF) marker at the same "
        "timestamp, causing the larger marker to cover the smaller one. The user noted 'levels "
        "should be light HTF to LTF not in opposite' — the visual hierarchy was correct (degree 3 "
        "= largest/most prominent) but the render order was wrong.",
        style_body
    ))
    story.append(Paragraph(
        "<b>Solution:</b> Added a sort step in <font name='Courier'>renderMarketObjectsLayer()</font> "
        "that orders candidates by degree DESCENDING (HTF degree-3 first, LTF degree-1 last), then "
        "by time ascending within the same degree. This ensures larger markers are painted in the "
        "background and smaller markers appear on top, so all degrees remain visible.",
        style_body
    ))
    story.append(Paragraph("<b>Code:</b>", style_h3))
    story.append(Paragraph("""filtered.sort((a, b) => {
  const degA = a.properties?.degree ||
    (a.concept_label && {STH:1,STL:1,ITH:2,ITL:2,LTH:3,LTL:3}[a.concept_label]) || 0;
  const degB = b.properties?.degree ||
    (b.concept_label && {STH:1,STL:1,ITH:2,ITL:2,LTH:3,LTL:3}[b.concept_label]) || 0;
  if (degA !== degB) return degB - degA;  // HTF first
  const ta = a.timeStart !== undefined ? a.timeStart : a.time;
  const tb = b.timeStart !== undefined ? b.timeStart : b.time;
  return ta - tb;  // Chronological within same degree
});""", style_code))

    story.append(Paragraph("14. Fix #13: Replay Time-Machine Scrubber", style_h1))
    story.append(Paragraph(
        "<b>Root Cause:</b> The replay controls only had step-forward/step-backward buttons and a "
        "speed slider. There was no way to instantly jump to any point in time — the user had to "
        "step through every bar one by one.",
        style_body
    ))
    story.append(Paragraph(
        "<b>Solution:</b> Added a full-width timeline scrubber slider to the ReplayControls "
        "component. The slider's min=1, max=allBars.length, and value=replayIndex. Dragging it "
        "instantly jumps to any bar. The slider track is styled with a gradient that fills blue "
        "up to the current position. Shows 'currentBar/totalBars' on the left and the current date "
        "on the right. This makes replay feel like a video player time machine.",
        style_body
    ))
    story.append(Paragraph("<b>Reusable AI Prompt:</b>", style_h3))
    story.append(Paragraph(
        "Add a time-machine scrubber to a chart replay control bar. Requirements: (1) A range "
        "input slider with min=1, max=totalBars, value=currentBarIndex. (2) On change, set the "
        "replay index and reset the sub-step counter. (3) Style the slider track with a "
        "linear-gradient that fills blue (#2962ff) up to the current position percentage and grey "
        "(#2a2e39) after. (4) Show 'currentBar/totalBars' label on the left and the current bar's "
        "date (formatted as 'Mon DD') on the right. (5) Use flex: 1 1 auto so it expands to fill "
        "available space. (6) Add a left border separator to visually distinguish it from other "
        "controls.",
        style_prompt
    ))
    story.append(PageBreak())

    # ─── OVERLAY ALIGNMENT FIX ─────────────────────────────────────────────
    story.append(Paragraph("14b. Fix #14: Overlay Canvas 28px Alignment — Markers Floating Above Candles", style_h1))
    story.append(Paragraph(
        "<b>Root Cause:</b> The chart-container has <font name='Courier'>padding-top: 28px</font> "
        "for the OHLCV header bar. The lightweight-charts canvas renders below this padding "
        "(at y=28 in the container). But the overlay canvases container was at "
        "<font name='Courier'>top: 0</font>, covering the full container including the header "
        "area. This created a 28px vertical offset — every overlay marker (swing, FVG, OB, "
        "liquidity line) was drawn 28px higher than its corresponding candle wick.",
        style_body
    ))
    story.append(Paragraph(
        "<b>Symptom:</b> Swing markers appeared to float in empty space above the candles. The "
        "chart looked broken, as if markers were unanchored from the price data.",
        style_body
    ))
    story.append(Paragraph(
        "<b>Why it was hard to find:</b> Each CSS property was correct in isolation: "
        "padding-top:28px (for the header), top:0 (for absolute positioning), height:100% "
        "(to fill the container). The bug only emerged from the interaction — padding affects "
        "the content box (where the chart canvas renders) but not absolutely-positioned "
        "children (the overlay container). This is a classic CSS gotcha that's invisible in "
        "code review but obvious in a screenshot.",
        style_body
    ))
    story.append(Paragraph("<b>Fix:</b>", style_h3))
    story.append(Paragraph("""// Before (BROKEN — overlay covers full container including 28px header):
<div style={{ top: 0, height: '100%' }}>

// After (FIXED — overlay starts below the header, matches chart canvas):
<div style={{ top: '28px', height: 'calc(100% - 28px)' }}>""", style_code))
    story.append(Paragraph(
        "Also updated <font name='Courier'>getChartDimensions()</font> to subtract the 28px "
        "header from the height calculation, so paneHeight matches the actual chart canvas.",
        style_body
    ))
    story.append(Paragraph(
        "<b>Verification:</b> DOM inspection confirmed chartTarget.top=68, overlayContainer.top=68, "
        "offset=0 (was 28 before). VLM confirmed markers moved from FLOATING to ON_WICKS.",
        style_body
    ))

    story.append(Paragraph("<b>Reusable AI Prompt:</b>", style_h3))
    story.append(Paragraph(
        "Fix a bug where chart overlay markers (drawn on canvas elements above a "
        "lightweight-charts candlestick chart) float ~28px above the candle wicks they're "
        "supposed to mark. The chart container has padding-top:28px for a header bar. The "
        "lightweight-charts canvas renders below this padding (in the content box), but the "
        "overlay canvas container is absolutely positioned at top:0, covering the full "
        "container including the padding area. Fix: set the overlay container to "
        "top:28px and height:calc(100% - 28px) so it matches the chart canvas's actual "
        "rendered area. Also update any dimension-calculating functions to subtract the "
        "header height. Verify with DOM inspection that chartTarget.top === "
        "overlayContainer.top (offset = 0).",
        style_prompt
    ))

    # ─── FUTURE BUGS ────────────────────────────────────────────────────────
    story.append(Paragraph("15. Future Bug Predictions & Preventive Fixes", style_h1))
    story.append(Paragraph(
        "Based on the architecture and patterns observed during this work, the following bugs are "
        "likely to emerge in the future. Each prediction includes the root cause, the preventive "
        "fix, and the AI prompt to implement it.",
        style_body
    ))

    story.append(Paragraph("Bug A: Memory Leak from Price-Scale Poll Loop", style_h2))
    story.append(Paragraph(
        "<b>Prediction:</b> The <font name='Courier'>requestAnimationFrame</font> poll loop in "
        "DrawingCanvas.jsx runs continuously at 60fps. If the component unmounts during a drag "
        "(e.g., user switches workspace tabs), the <font name='Courier'>cancelAnimationFrame</font> in "
        "the cleanup function may not fire if the unmount happens between frames. The poll "
        "continues calling <font name='Courier'>chart.priceScale()</font> on a disposed chart, causing "
        "errors and memory retention.",
        style_body
    ))
    story.append(Paragraph(
        "<b>Preventive Fix:</b> The cleanup already calls <font name='Courier'>cancelAnimationFrame"
        "(priceScaleRafId)</font>, but add a <font name='Courier'>isMountedRef.current</font> check at "
        "the TOP of the poll function (before any chart API call) to bail out immediately if the "
        "component unmounted between the rAF scheduling and the callback execution. Also wrap the "
        "chart API calls in try/catch to silently swallow errors from disposed charts.",
        style_body
    ))

    story.append(Paragraph("Bug B: Stale Closure in handleTriggerSync After Upstream Merge", style_h2))
    story.append(Paragraph(
        "<b>Prediction:</b> The upstream GitHub repo re-introduced <font name='Courier'>http://localhost:8080</font> "
        "in the <font name='Courier'>handleTriggerSync</font> function. If the user pulls future "
        "upstream commits that add new fetch calls, those calls will also use hardcoded URLs. The "
        "sed-based fix is reactive, not preventive.",
        style_body
    ))
    story.append(Paragraph(
        "<b>Preventive Fix:</b> Add a Vite build-time check that scans all .jsx/.js files for "
        "<font name='Courier'>localhost:8080</font> and fails the build if found. Implement as a Vite "
        "plugin in <font name='Courier'>vite.config.js</font> that runs during the <font name='Courier'>"
        "transform</font> hook. Alternatively, create a shared <font name='Courier'>apiFetch()</font> "
        "utility that all components import, and ban raw <font name='Courier'>fetch()</font> calls to "
        "absolute URLs via an ESLint rule.",
        style_body
    ))

    story.append(Paragraph("Bug C: AI Swing Engine HTF Timeframe Hardcoded to 15m", style_h2))
    story.append(Paragraph(
        "<b>Prediction:</b> The AI swing engine's HTF alignment factor aggregates 1m bars to 15m "
        "for the higher-timeframe swing check. If the user views the chart at 5m or 1h, the HTF "
        "alignment will still use 15m, which is incorrect — at 5m the HTF should be 1h, at 1h the "
        "HTF should be 4h.",
        style_body
    ))
    story.append(Paragraph(
        "<b>Preventive Fix:</b> Parameterize the HTF timeframe: pass the current chart timeframe "
        "to the AI swing engine, and compute the HTF as <font name='Courier'>chartTf × 15</font> "
        "(clamped to standard timeframes: 1→15, 5→60, 15→240, 60→1440). The /api/ai/swings endpoint "
        "already accepts a <font name='Courier'>timeframe</font> param — thread it through to the "
        "engine's HTF aggregation step.",
        style_body
    ))

    story.append(Paragraph("Bug D: DrawingCanvas Overlay Canvas DPR Mismatch on Window Move", style_h2))
    story.append(Paragraph(
        "<b>Prediction:</b> The overlay canvases use <font name='Courier'>window.devicePixelRatio</font> "
        "for backing-store scaling. If the user drags the browser window to a monitor with a "
        "different DPR (e.g., from a 1x laptop screen to a 2x Retina display), the canvases don't "
        "re-render at the new DPR, causing blurry or incorrectly-scaled overlays.",
        style_body
    ))
    story.append(Paragraph(
        "<b>Preventive Fix:</b> Add a <font name='Courier'>window.matchMedia('(resolution: ...dppx)')"
        ".addEventListener('change', ...)</font> listener that calls <font name='Courier'>updateCanvasSize()</font> "
        "and <font name='Courier'>schedulerRef.current.markAllDirty()</font> when the DPR changes. "
        "Alternatively, use a <font name='Courier'>ResizeObserver</font> on <font name='Courier'>window"
        ".visualViewport</font>.",
        style_body
    ))

    story.append(Paragraph("Bug E: Sync Worker Race Condition on Rapid Symbol Switch", style_h2))
    story.append(Paragraph(
        "<b>Prediction:</b> When the user rapidly switches symbols (click-click-click in the "
        "watchlist), multiple sync workers can spawn before the first one finishes. The "
        "<font name='Courier'>activeSyncWorker</font> guard prevents parallel spawns, but if the first "
        "worker is slow, the user sees stale data from the old symbol while the new symbol's data "
        "is still loading.",
        style_body
    ))
    story.append(Paragraph(
        "<b>Preventive Fix:</b> Add an <font name='Courier'>AbortController</font> to the data fetch "
        "in App.jsx that's aborted when the symbol changes. Show a 'Loading {symbol}…' overlay "
        "while the fetch is in-flight. Cache the last-known-good data per symbol so the chart "
        "shows the previous symbol's data (greyed out) instead of blank during the transition.",
        style_body
    ))
    story.append(PageBreak())

    # ─── AI PROMPTS ─────────────────────────────────────────────────────────
    story.append(Paragraph("16. Reusable AI Prompts for Google Antigravity", style_h1))
    story.append(Paragraph(
        "The following prompts are designed to be pasted directly into a Google Antigravity agent "
        "session to reproduce or apply each fix to any similar codebase. Each prompt is self-"
        "contained and includes the problem description, the solution approach, and verification "
        "steps.",
        style_body
    ))

    prompts = [
        ("Prompt 1: Cross-Platform Path Fix",
         "Fix cross-platform path hardcoding in a Node.js file. Replace Windows-specific paths "
         "like 'D:\\\\nijna data' with a priority list: (1) process.env.MY_DATA_DIR, (2) a repo-local "
         "'./data' directory, (3) the original Windows paths as fallback. Use path.join() and "
         "filter(Boolean). Verify the symbol-discovery API returns at least one result."),

        ("Prompt 2: Remove Hardcoded Backend URLs",
         "Find all hardcoded 'http://localhost:PORT' references in a React frontend and replace "
         "with relative URLs (e.g., '/api/endpoint'). Use sed across all .jsx and .js files. "
         "Verify with: grep -rn 'localhost:' frontend/src/ (should return 0 results)."),

        ("Prompt 3: Single-Port Deployment",
         "Configure a Vite + React frontend and Node.js backend for single-port deployment. "
         "(1) Add Vite proxy for '/api/*' to the backend. (2) Add static-file serving to the "
         "backend for built frontend assets (frontend/dist/). (3) Add SPA fallback to index.html. "
         "Include a MIME type map. (4) Set PORT from env var."),

        ("Prompt 4: Synthetic Data Generator",
         "Generate 12,000 synthetic 1-minute OHLC bars for a futures trading terminal. Use "
         "geometric Brownian motion with seeded RNG, intraday seasonality, regime switching every "
         "240 bars, and 0.8% probability displacement jumps. Skip weekends. Write as CSV. Also "
         "detect 3-bar fractal swings and insert into a SQLite structure_events table."),

        ("Prompt 5: PDOS Swing Engine",
         "Implement a windowed swing detector: (1) Candidate scan with ≤/≥ neighbor comparison. "
         "(2) Flat-run resolution with priority scoring (0 if dual-qualified, 1 otherwise, ties "
         "to rightmost). (3) Outside-bar alternation. (4) Recursive hierarchy promotion (degrees "
         "2 and 3). (5) Strength score via symmetric window expansion. Use Uint8Array/Float64Array. "
         "Process 12k bars in <500ms."),

        ("Prompt 6: AI Confluence Swing Engine",
         "Build a 7-factor confluence-scored swing detector. Factors: fractal (25%), displacement "
         "(20%), volume (15%), BSL/SSL sweep (15%), RSI divergence (10%), session (5%), HTF "
         "alignment (10%). Score 0-100, emit only ≥40. Precompute ATR-14, RSI-14, avg volume into "
         "Float64Array. Add GET API endpoint with min_score and limit params."),

        ("Prompt 7: TradingView Pro UI Redesign",
         "Redesign a React trading terminal to match TradingView Pro. CSS grid: 40px toolbar / "
         "1fr main / 24px status bar. Main row: 48px rail / 1fr chart / 280px panel. Palette: "
         "#0e0e0e, #161616, #1c1c1c, #2a2e39, #d1d4dc, #2962ff. Replace emoji with lucide-react "
         "icons (14px). Add CSS tooltips, bottom status bar with connection/price/AI ticker. "
         "No inline styles."),

        ("Prompt 8: Price-Axis Drag Fix",
         "Fix chart overlay markers not tracking candles during price-axis drag. lightweight-charts "
         "v5 has no price-scale change event. Solution: poll chart.priceScale('right')."
         "getVisibleRange() on every requestAnimationFrame. When it changes, disable the projection "
         "cache (bypass Map, call series.priceToCoordinate() live). After 3 stable frames, "
         "re-enable cache. Add cancelAnimationFrame in cleanup."),

        ("Prompt 9: Performance Optimization",
         "Optimize a React SPA for fast initial load. (1) Lazy-load heavy tab components with "
         "React.lazy + Suspense. (2) Reduce initial fetch limits (10k→3k candles, 15k→5k events). "
         "(3) Add CSS containment on heavy regions. (4) GPU-accelerate canvases. (5) Add loading "
         "skeletons. Target: main bundle <650KB, initial fetch <5k items."),

        ("Prompt 10: HTF→LTF Render Order",
         "Fix chart overlay z-ordering so larger (HTF) markers render in the background and "
         "smaller (LTF) markers on top. Sort candidates by degree DESCENDING before the render "
         "loop. Within the same degree, preserve chronological order. This prevents large markers "
         "from hiding small ones at the same timestamp."),

        ("Prompt 11: Replay Time-Machine Scrubber",
         "Add a timeline scrubber to chart replay controls. Range input: min=1, max=totalBars, "
         "value=currentIndex. On change, jump to that bar. Style with a blue-to-grey gradient "
         "track. Show 'current/total' and current date labels. Use flex: 1 1 auto for expansion."),

        ("Prompt 12: Responsive Layout Breakpoints",
         "Add responsive CSS breakpoints to a trading terminal. ≤1200px: shrink right panel to "
         "240px. ≤900px: hide right panel and non-essential toolbar buttons. ≤700px: hide left "
         "rail, shrink tab/button text. Change toolbar overflow from hidden to auto with hidden "
         "scrollbars."),
    ]

    for title, prompt_text in prompts:
        story.append(Paragraph(title, style_h3))
        story.append(Paragraph(prompt_text, style_prompt))
        story.append(Spacer(1, 3*mm))

    story.append(PageBreak())

    # ─── ARCHITECTURE ───────────────────────────────────────────────────────
    story.append(Paragraph("17. Architecture Reference", style_h1))

    story.append(Paragraph("System Overview", style_h2))
    story.append(Paragraph(
        "The PDOS terminal is a two-tier application: a Node.js backend "
        "(<font name='Courier'>server.js</font>) serving API endpoints from port 3000, and a React "
        "frontend (built via Vite) served as static assets from the same port. The preview gateway "
        "on port 81 proxies external traffic to port 3000. The backend uses <font name='Courier'>"
        "node:sqlite</font> (the built-in SQLite module in Node 24+) for data storage, with the "
        "database file at <font name='Courier'>market_research_v2.db</font>.",
        style_body
    ))

    story.append(Paragraph("Key Files", style_h2))
    arch_files = [
        ['File', 'Purpose', 'Lines'],
        ['server.js', 'HTTP server + all API routes + static frontend serving', '1230'],
        ['algo/dataLoader.js', 'CSV parsing, symbol discovery, time aggregation', '580'],
        ['algo/db.js', 'SQLite schema + migration + connection pool', '596'],
        ['algo/QueryEngine.js', 'Candle/event/liquidity query layer', '240'],
        ['algo/pipeline.js', 'Full PDOS detection pipeline (1400 lines)', '1403'],
        ['algo/engines/aiSwingEngine.js', 'AI 7-factor confluence swing detector', '350'],
        ['algo/engines/swingService.js', 'Production swing detection service', '154'],
        ['frontend/src/App.jsx', 'Main React component (toolbar, chart, panels)', '3020'],
        ['frontend/src/index.css', 'TradingView Pro dark theme + 35 component classes', '2700'],
        ['frontend/src/components/DrawingCanvas.jsx', 'Overlay canvas renderer (14 layers)', '3830'],
        ['frontend/src/components/ChartProjectionService.js', 'Coordinate projection + cache', '110'],
        ['scripts/seed_demo_data.js', 'Synthetic data + swing detection seeder', '630'],
        ['scripts/start_pdos.sh', 'Single-command launcher (build + start)', '35'],
    ]
    arch_table = Table(arch_files, colWidths=[55*mm, 85*mm, 20*mm])
    arch_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), C_ACCENT),
        ('FONTNAME', (0,0), (-1,0), BOLD_FONT),
        ('FONTSIZE', (0,0), (-1,0), 9),
        ('TEXTCOLOR', (0,0), (-1,0), white),
        ('FONTNAME', (0,1), (0,-1), MONO_FONT),
        ('FONTSIZE', (0,1), (-1,-1), 8.5),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('LINEBELOW', (0,0), (-1,-1), 0.3, C_BORDER),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ('TOPPADDING', (0,0), (-1,-1), 4),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [white, HexColor('#f8f9fa')]),
    ]))
    story.append(arch_table)
    story.append(Spacer(1, 6*mm))

    story.append(Paragraph("API Endpoints", style_h2))
    api_data = [
        ['Method', 'Endpoint', 'Purpose'],
        ['GET', '/api/symbols', 'List discovered CSV symbols'],
        ['GET', '/api/symbol-info?symbol=X', 'Date range for symbol'],
        ['GET', '/api/data?symbol=X&tf=1&limit=N', 'Fetch candlestick bars'],
        ['GET', '/api/events?symbol=X&tf=1', 'Fetch structure events (swings, FVGs, OBs)'],
        ['GET', '/api/query/visible-window?symbol=X&tf=1', 'Combined candles + events for viewport'],
        ['GET', '/api/ai/swings?symbol=X&min_score=60', 'AI confluence-scored swings'],
        ['GET', '/api/ai/swings/factors', 'Factor weight documentation'],
        ['POST', '/api/algo/labels', 'Save human-labeled annotations'],
        ['GET', '/api/algo/sync?symbol=X&trigger=true', 'Trigger pipeline sync'],
        ['GET', '/api/diagnostics/telemetry', 'Server health + DB stats'],
        ['POST', '/api/validations', 'Save human validation of events'],
        ['GET/POST/DELETE', '/api/trades', 'Simulator trade log CRUD'],
    ]
    api_table = Table(api_data, colWidths=[25*mm, 65*mm, 70*mm])
    api_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), C_ACCENT),
        ('FONTNAME', (0,0), (-1,0), BOLD_FONT),
        ('FONTSIZE', (0,0), (-1,-1), 8.5),
        ('TEXTCOLOR', (0,0), (-1,0), white),
        ('FONTNAME', (1,1), (1,-1), MONO_FONT),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('LINEBELOW', (0,0), (-1,-1), 0.3, C_BORDER),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ('TOPPADDING', (0,0), (-1,-1), 4),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [white, HexColor('#f8f9fa')]),
    ]))
    story.append(api_table)
    story.append(PageBreak())

    # ─── QUICK COMMANDS ─────────────────────────────────────────────────────
    story.append(Paragraph("18. Quick Command Reference", style_h1))

    story.append(Paragraph("Startup", style_h2))
    story.append(Paragraph("# Full rebuild + start (port 3000)\nbash /home/z/my-project/scripts/start_pdos.sh", style_code))

    story.append(Paragraph("Manual Build + Start", style_h2))
    story.append(Paragraph("""# Build frontend
cd /home/z/my-project/_PDOS/frontend && npx vite build

# Start backend on port 3000
cd /home/z/my-project/_PDOS && PORT=3000 node server.js &

# Verify
curl http://127.0.0.1:3000/api/symbols""", style_code))

    story.append(Paragraph("Re-seed Data", style_h2))
    story.append(Paragraph("""# Delete old DB and re-seed with 12k bars
rm /home/z/my-project/_PDOS/market_research_v2.db
node /home/z/my-project/scripts/seed_demo_data.js

# Or with more bars
BARS_COUNT=20000 node /home/z/my-project/scripts/seed_demo_data.js""", style_code))

    story.append(Paragraph("Debug Price-Axis Drag", style_h2))
    story.append(Paragraph("""# Check if the poll loop is running (browser console):
# Should see "[DrawingCanvas] Price-scale poll STARTED" on page load

# Verify getVisibleRange changes during drag:
# Open browser console, drag price axis, look for "Price scale CHANGED" logs""", style_code))

    story.append(Paragraph("Test AI Swings API", style_h2))
    story.append(Paragraph("""# Get high-confidence swings
curl "http://127.0.0.1:3000/api/ai/swings?symbol=NQ_Historical_Data&timeframe=1&min_score=60&limit=50"

# Get factor documentation
curl "http://127.0.0.1:3000/api/ai/swings/factors\"""", style_code))

    story.append(Paragraph("Browser Verification", style_h2))
    story.append(Paragraph("""# Open chart
agent-browser open http://127.0.0.1:81/
sleep 5

# Check for errors
agent-browser errors

# Screenshot
agent-browser screenshot /tmp/chart.png

# VLM verify
z-ai vision -p "Describe the chart" -i /tmp/chart.png""", style_code))

    story.append(Paragraph("Git Operations", style_h2))
    story.append(Paragraph("""# Pull latest from upstream
cd /home/z/my-project/_PDOS
git stash                    # Save local changes
git pull origin main         # Pull upstream
git stash pop                # Restore local changes

# Re-apply URL fix (upstream may re-introduce localhost:8080)
cd frontend/src && sed -i 's|http://localhost:8080||g' App.jsx

# Rebuild
cd .. && npx vite build""", style_code))

    story.append(Spacer(1, 10*mm))
    story.append(HRFlowable(width="100%", thickness=1, color=C_ACCENT))
    story.append(Spacer(1, 4*mm))
    story.append(Paragraph(
        "This document was generated as part of the PDOS terminal optimization project. "
        "All fixes have been verified via headless browser testing and VLM (Vision Language Model) "
        "screenshot analysis. For the Google Antigravity agent: paste any prompt from Section 16 "
        "into a new session to reproduce the corresponding fix on any similar codebase.",
        style_footer
    ))

    # Build PDF
    doc.build(story, onFirstPage=header_footer, onLaterPages=header_footer)
    print(f"✓ PDF generated: {output_path}")
    print(f"  Size: {os.path.getsize(output_path) / 1024:.1f} KB")
    return output_path


if __name__ == '__main__':
    build_pdf()
