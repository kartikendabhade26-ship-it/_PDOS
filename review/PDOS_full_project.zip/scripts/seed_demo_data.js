/**
 * scripts/seed_demo_data.js
 *
 * Generates a self-contained synthetic NQ futures dataset and seeds the PDOS
 * SQLite database with bars + structure events so the UI has something to draw
 * out of the box. Also writes a CSV to _PDOS/data/ so the backend's
 * /api/symbols endpoint discovers the symbol.
 *
 * Usage:
 *   node /home/z/my-project/scripts/seed_demo_data.js
 *
 * Env:
 *   PDOS_REPO   – path to the _PDOS repo (default /home/z/my-project/_PDOS)
 *   BARS_COUNT  – number of 1-min bars to generate (default 12000 ≈ 8 sessions)
 */

const fs = require('fs');
const path = require('path');

const REPO = process.env.PDOS_REPO || '/home/z/my-project/_PDOS';
const BARS_COUNT = parseInt(process.env.BARS_COUNT || '12000', 10);
const SYMBOL = 'NQ_Historical_Data';
const RUN_ID = 'run_dev';

// ─── 1. Generate synthetic OHLC bars ───────────────────────────────────────
function generateBars(count) {
  // NQ futures around 20,000 with intraday seasonality + occasional jumps.
  // 1-minute bars. Trading hours: 18:00 ET Sunday → 17:00 ET Friday (nearly 24h).
  // We generate contiguous bars from a start date, skipping weekends.

  const bars = [];
  let price = 20000;
  const startTime = Math.floor(Date.UTC(2025, 4, 5, 13, 30, 0) / 1000); // 2025-05-05 13:30 UTC (09:30 ET)
  let t = startTime;
  let drift = 0;
  let vol = 1.5;

  // Simple RNG with seed for reproducibility
  let seed = 1234567;
  const rand = () => {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    return seed / 4294967296;
  };
  const gaussian = () => {
    // Box-Muller
    const u = Math.max(1e-9, rand());
    const v = rand();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  };

  for (let i = 0; i < count; i++) {
    // Skip weekends (Fri 17:00 ET = 21:00 UTC Sat → Sun 18:00 ET = 22:00 UTC Sun)
    const dow = new Date(t * 1000).getUTCDay();
    const hourUTC = new Date(t * 1000).getUTCHours();
    if (dow === 6 || (dow === 5 && hourUTC >= 21) || (dow === 0 && hourUTC < 22)) {
      t += 60;
      i--;
      continue;
    }

    // Slowly vary drift and volatility (regime switching)
    if (i % 240 === 0) {
      drift = (rand() - 0.5) * 0.3;
      vol = 1.0 + rand() * 3.0;
    }
    // Occasional displacement (jump)
    let jump = 0;
    if (rand() < 0.008) {
      jump = (rand() - 0.5) * 25;
    }

    const open = price;
    const change = drift + gaussian() * vol + jump;
    const close = Math.max(1000, open + change);
    const high = Math.max(open, close) + Math.abs(gaussian()) * vol * 0.7;
    const low = Math.min(open, close) - Math.abs(gaussian()) * vol * 0.7;
    const volume = Math.floor(500 + rand() * 4500 + Math.abs(change) * 100);

    bars.push({ time: t, open, high, low, close, volume });
    price = close;
    t += 60;
  }
  return bars;
}

// ─── 2. Aggregate to higher timeframes ──────────────────────────────────────
function aggregate(bars, tfMinutes) {
  if (tfMinutes <= 1) return bars;
  const step = tfMinutes * 60;
  const out = [];
  let cur = null;
  let bucket = -1;
  for (const b of bars) {
    const bb = Math.floor(b.time / step) * step;
    if (bb !== bucket) {
      if (cur) out.push(cur);
      bucket = bb;
      cur = { time: bb, open: b.open, high: b.high, low: b.low, close: b.close, volume: b.volume };
    } else {
      cur.high = Math.max(cur.high, b.high);
      cur.low = Math.min(cur.low, b.low);
      cur.close = b.close;
      cur.volume += b.volume;
    }
  }
  if (cur) out.push(cur);
  return out;
}

// ─── 3. PDOS Swing Engine (spec-exact port of swingMath + swingService + ──
//         swingSequenceResolver + swingHierarchyBuilder) ─────────────────────
//
// Mirrors the production algo/engines/* logic exactly so the seed data is
// consistent with what the real pipeline would produce.
//
// Pipeline: candidate scan → flat-run resolution → outside-bar alternation →
//           hierarchy promotion (degrees 2 & 3) → strength score.

// Candidate scan (mirrors algo/engines/swingMath.js scanSwingCandidates).
//   High candidate: no neighbor in window has high > curr.high, AND at least
//                   one neighbor has high < curr.high.
//   Low  candidate: no neighbor in window has low  < curr.low,  AND at least
//                   one neighbor has low  > curr.low.
function scanSwingCandidates(bars, leftLen, rightLen) {
  const isHighCand = new Uint8Array(bars.length);
  const isLowCand  = new Uint8Array(bars.length);
  for (let i = leftLen; i < bars.length - rightLen; i++) {
    const c = bars[i];
    let allLowerOrEqualHigh = true;
    let hasStrictlyLowerHigh = false;
    let allHigherOrEqualLow = true;
    let hasStrictlyHigherLow = false;
    for (let j = i - leftLen; j <= i + rightLen; j++) {
      if (bars[j].high > c.high) { allLowerOrEqualHigh = false; }
      if (bars[j].high < c.high) { hasStrictlyLowerHigh = true; }
      if (bars[j].low  < c.low)  { allHigherOrEqualLow  = false; }
      if (bars[j].low  > c.low)  { hasStrictlyHigherLow = true; }
    }
    if (allLowerOrEqualHigh && hasStrictlyLowerHigh) isHighCand[i] = 1;
    if (allHigherOrEqualLow && hasStrictlyHigherLow) isLowCand[i]  = 1;
  }
  return { isHighCand, isLowCand };
}

// Flat-run resolution (mirrors resolveFlatRuns).
//   For each run of consecutive same-type candidates at the same wick price,
//   pick the index with the highest score (score = 0 if dual-qualified, else 1).
//   On tie, pick the rightmost index. The confirmation bar = R + rightLen.
function resolveFlatRuns(bars, isCand, opposingCand, isHighSide) {
  const finalIndices  = new Uint8Array(bars.length);
  const confirmIndices = new Int32Array(bars.length);
  let i = 0;
  while (i < bars.length) {
    if (isCand[i] === 1) {
      let L = i, R = i;
      const target = isHighSide ? bars[L].high : bars[L].low;
      while (R + 1 < bars.length && isCand[R + 1] === 1 &&
             (isHighSide ? bars[R + 1].high === target : bars[R + 1].low === target)) {
        R++;
      }
      let bestIdx = L, maxScore = -1;
      for (let idx = L; idx <= R; idx++) {
        const score = opposingCand[idx] === 1 ? 0 : 1;
        if (score >= maxScore) { maxScore = score; bestIdx = idx; }
      }
      finalIndices[bestIdx] = 1;
      confirmIndices[bestIdx] = R;
      i = R + 1;
    } else {
      i++;
    }
  }
  return { finalIndices, confirmIndices };
}

// Sequence alternation (mirrors swingSequenceResolver.resolveSequences).
//   Sort by barIndex; if same barIndex (outside bar), order to enforce strict
//   alternation with the prior pivot.
function resolveSequences(swings) {
  if (!swings || swings.length === 0) return [];
  swings.sort((a, b) => a.barIndex - b.barIndex);
  const ordered = [];
  for (const sw of swings) {
    if (ordered.length === 0) { ordered.push(sw); continue; }
    const last = ordered[ordered.length - 1];
    if (last.barIndex === sw.barIndex) {
      // Outside bar: order to alternate with the prior
      const prior = ordered[ordered.length - 2];
      const priorType = prior ? prior.type : (last.type === 'swing_high' ? 'swing_low' : 'swing_high');
      if (priorType === 'swing_high') {
        // Want High -> Low -> High, so prior=High means last must be Low, sw must be High
        if (last.type === 'swing_high') { ordered[ordered.length - 1] = sw; ordered.push(last); }
        else { ordered.push(sw); }
      } else {
        // Want Low -> High -> Low, so prior=Low means last must be High, sw must be Low
        if (last.type === 'swing_low') { ordered[ordered.length - 1] = sw; ordered.push(last); }
        else { ordered.push(sw); }
      }
      continue;
    }
    ordered.push(sw);
  }
  for (const sw of ordered) { sw.isStructural = true; sw.renderHint = 'normal'; }
  return ordered;
}

// Recursive hierarchy promotion (mirrors swingHierarchyBuilder.build).
//   Degree N swing is promoted when middle of [prev, middle, next] is the
//   extreme among the three. Links parent/child IDs.
function buildHierarchy(degree1Swings, maxDegree = 3) {
  if (!degree1Swings || degree1Swings.length < 3) return [];
  degree1Swings.sort((a, b) => a.barIndex - b.barIndex);
  const swingMap = new Map(degree1Swings.map(s => [s.id, s]));
  const allPromoted = [];
  let curHighs = degree1Swings.filter(s => s.type === 'swing_high');
  let curLows  = degree1Swings.filter(s => s.type === 'swing_low');
  for (let targetDegree = 2; targetDegree <= maxDegree; targetDegree++) {
    const promoH = _buildOneSide(curHighs, 'swing_high', targetDegree, swingMap);
    const promoL = _buildOneSide(curLows,  'swing_low',  targetDegree, swingMap);
    allPromoted.push(...promoH, ...promoL);
    promoH.forEach(s => swingMap.set(s.id, s));
    promoL.forEach(s => swingMap.set(s.id, s));
    curHighs = promoH;
    curLows  = promoL;
    if (promoH.length === 0 && promoL.length === 0) break;
  }
  return allPromoted;
}
function _buildOneSide(swings, type, targetDegree, swingMap) {
  const promoted = [];
  const isHigh = type === 'swing_high';
  for (let i = 1; i < swings.length - 1; i++) {
    const prev = swings[i - 1], middle = swings[i], next = swings[i + 1];
    const qualifies = isHigh
      ? (middle.price > prev.price && middle.price > next.price)
      : (middle.price < prev.price && middle.price < next.price);
    if (qualifies) {
      const id = `swing_${isHigh ? 'high' : 'low'}_d${targetDegree}_${middle.time}`;
      const entry = {
        id, type, concept: 'swing', direction: middle.direction,
        time: middle.time, timestamp: middle.time,
        price: middle.price, priceHigh: middle.priceHigh, priceLow: middle.priceLow,
        barIndex: middle.barIndex, confirmationBar: middle.confirmationBar,
        timeframe: middle.timeframe, symbol: middle.symbol,
        degree: targetDegree,
        childSwingIds: [prev.id, middle.id, next.id]
      };
      [prev.id, middle.id, next.id].forEach(childId => {
        const child = swingMap.get(childId);
        if (child) {
          if (!child.parentSwingIds) child.parentSwingIds = [];
          if (!child.parentSwingIds.includes(id)) child.parentSwingIds.push(id);
        }
      });
      promoted.push(entry);
    }
  }
  return promoted;
}

// Strength score (mirrors primitives.calculateSwingStrength).
//   For a swing high at index i with price P, expand the window left and right
//   as long as every bar's high is strictly < P. The max symmetric radius that
//   holds is the strength. Same for swing lows (low > P).
function calculateStrength(bars, idx, isHigh) {
  const price = isHigh ? bars[idx].high : bars[idx].low;
  let strength = 0;
  while (true) {
    const L = idx - (strength + 1);
    const R = idx + (strength + 1);
    if (L < 0 || R >= bars.length) break;
    const okL = isHigh ? bars[L].high < price : bars[L].low > price;
    const okR = isHigh ? bars[R].high < price : bars[R].low > price;
    if (okL && okR) strength++;
    else break;
  }
  return strength;
}

// Top-level swing engine entry point — mirrors SwingService.detect().
//   - leftLen=1, rightLen=1 (3-bar fractal) for degree-1 candidates
//   - Builds degrees 2 and 3 via hierarchy promotion
//   - Returns all swings (degree 1, 2, 3) with alternation enforced on deg-1
function findSwings(bars, timeframe = 1, symbol = SYMBOL) {
  const leftLen = 1, rightLen = 1;
  const { isHighCand, isLowCand } = scanSwingCandidates(bars, leftLen, rightLen);
  const { finalIndices: finalHighs, confirmIndices: confirmHighs } =
    resolveFlatRuns(bars, isHighCand, isLowCand, true);
  const { finalIndices: finalLows, confirmIndices: confirmLows } =
    resolveFlatRuns(bars, isLowCand, isHighCand, false);

  const d1Swings = [];
  for (let idx = 0; idx < bars.length; idx++) {
    const b = bars[idx];
    if (finalHighs[idx] === 1) {
      d1Swings.push({
        id: `swing_high_${b.time}`, type: 'swing_high', concept: 'swing',
        direction: 'bearish', time: b.time, timestamp: b.time,
        price: b.high, priceHigh: b.high, priceLow: b.low,
        barIndex: idx, confirmationBar: confirmHighs[idx] + rightLen,
        timeframe, symbol, degree: 1
      });
    }
    if (finalLows[idx] === 1) {
      d1Swings.push({
        id: `swing_low_${b.time}`, type: 'swing_low', concept: 'swing',
        direction: 'bullish', time: b.time, timestamp: b.time,
        price: b.low, priceHigh: b.high, priceLow: b.low,
        barIndex: idx, confirmationBar: confirmLows[idx] + rightLen,
        timeframe, symbol, degree: 1
      });
    }
  }

  // Enforce alternation on degree-1 chain
  const resolvedD1 = resolveSequences(d1Swings);

  // Build degrees 2 and 3
  const promoted = buildHierarchy(resolvedD1, 3);
  for (const ps of promoted) {
    ps.isStructural = true;
    ps.renderHint = 'normal';
  }
  const allSwings = [...resolvedD1, ...promoted];

  // Make IDs unique across timeframes; assign strength + properties
  for (const s of allSwings) {
    s.id = `${s.id}_tf${timeframe}`;
    if (s.parentSwingIds) s.parentSwingIds = s.parentSwingIds.map(pid => pid.includes('_tf') ? pid : `${pid}_tf${timeframe}`);
    if (s.childSwingIds)  s.childSwingIds  = s.childSwingIds.map(cid  => cid.includes('_tf') ? cid  : `${cid}_tf${timeframe}`);
    s.strength = calculateStrength(bars, s.barIndex, s.type === 'swing_high');
    s.state = 'confirmed';
    s.properties = {
      degree: s.degree,
      state: 'confirmed',
      derivedFrom: '3_bar_fractal',
      resolution: 'flat_group_last',
      parentSwingIds: s.parentSwingIds || [],
      childSwingIds: s.childSwingIds || [],
      maxStrength: s.strength,
      qualityScore: Math.min(100, s.degree * 25 + s.strength * 5),
      isStructural: s.isStructural,
      renderHint: s.renderHint || (s.isStructural ? 'normal' : 'hidden')
    };
  }

  // Convert to the {highs, lows} shape the rest of the seed script expects
  const highs = allSwings
    .filter(s => s.type === 'swing_high')
    .map(s => ({ idx: s.barIndex, time: s.time, price: s.price, degree: s.degree, strength: s.strength, id: s.id }));
  const lows = allSwings
    .filter(s => s.type === 'swing_low')
    .map(s => ({ idx: s.barIndex, time: s.time, price: s.price, degree: s.degree, strength: s.strength, id: s.id }));
  return { highs, lows, all: allSwings };
}

// ─── 4. Detect FVGs (3-bar gap) ────────────────────────────────────────────
function findFVGs(bars) {
  const fvgs = [];
  for (let i = 2; i < bars.length; i++) {
    const b1 = bars[i - 2], b3 = bars[i];
    // Bullish FVG (BISI): b1.high < b3.low  → gap up
    if (b1.high < b3.low) {
      fvgs.push({
        idx: i - 1,
        timeStart: b1.time,
        timeEnd: b3.time,
        priceHigh: b3.low,
        priceLow: b1.high,
        direction: 'bullish',
        kind: 'BISI'
      });
    }
    // Bearish FVG (SIBI): b1.low > b3.high → gap down
    if (b1.low > b3.high) {
      fvgs.push({
        idx: i - 1,
        timeStart: b1.time,
        timeEnd: b3.time,
        priceHigh: b1.low,
        priceLow: b3.high,
        direction: 'bearish',
        kind: 'SIBI'
      });
    }
  }
  return fvgs;
}

// ─── 5. Detect Order Blocks (last opposite-color candle before strong move) ─
function findOrderBlocks(bars, displacement = 5) {
  const obs = [];
  for (let i = 5; i < bars.length - 1; i++) {
    const move = bars[i + 1].close - bars[i].close;
    if (Math.abs(move) < displacement) continue;

    // Bullish OB: last down-candle before up-move
    if (move > 0 && bars[i].close < bars[i].open) {
      obs.push({
        idx: i,
        timeStart: bars[i].time,
        timeEnd: bars[i + 1].time,
        priceHigh: bars[i].high,
        priceLow: bars[i].low,
        direction: 'bullish',
        kind: 'OB'
      });
    }
    // Bearish OB: last up-candle before down-move
    if (move < 0 && bars[i].close > bars[i].open) {
      obs.push({
        idx: i,
        timeStart: bars[i].time,
        timeEnd: bars[i + 1].time,
        priceHigh: bars[i].high,
        priceLow: bars[i].low,
        direction: 'bearish',
        kind: 'OB'
      });
    }
  }
  return obs;
}

// ─── 6. Build event records ────────────────────────────────────────────────
function buildEvents(bars, tf) {
  const events = [];
  // findSwings(bars, timeframe, symbol) — pass tf so IDs include the timeframe
  const swingResult = findSwings(bars, tf, SYMBOL);
  const { highs, lows, all: allSwings } = swingResult;
  const fvgs = findFVGs(bars);
  const obs = findOrderBlocks(bars, 5);

  let counter = 0;
  const eid = (prefix) => `${prefix}_${RUN_ID}_${tf}_${counter++}`;

  // Swings — emit one event per swing (all degrees). The UI's SwingRenderer
  // filters by degree/strength when drawing, but we persist every confirmed
  // pivot per the PDOS spec ("Visibility != Existence").
  for (const s of allSwings) {
    const isHigh = s.type === 'swing_high';
    events.push({
      event_id: s.id,                       // spec: id is the canonical pivot id
      root_event_id: null,
      parent_event_id: (s.parentSwingIds && s.parentSwingIds[0]) || null,
      detector_id: 'SWING_v1',
      symbol: SYMBOL,
      timeframe: tf,
      concept_family: 'Swings',
      concept_type: isHigh ? 'STH' : 'STL',
      concept_state: 'active',
      time_start: s.time,
      time_end: s.time,
      price_high: s.price,
      price_low: s.price,
      direction: isHigh ? 'bearish' : 'bullish',
      properties: JSON.stringify({
        swing_type: isHigh ? 'high' : 'low',
        degree: s.degree,                   // 1, 2, or 3
        bar_index: s.barIndex,
        strength: s.strength,
        confirmation_bar: s.confirmationBar,
        parent_swing_ids: s.parentSwingIds || [],
        child_swing_ids: s.childSwingIds || [],
        is_structural: s.isStructural !== false,
        render_hint: s.renderHint || 'normal',
        quality_score: Math.min(100, s.degree * 25 + s.strength * 5),
        derived_from: '3_bar_fractal',
        resolution: 'flat_group_last'
      })
    });
  }
  for (const f of fvgs) {
    events.push({
      event_id: eid(f.kind),
      root_event_id: null,
      parent_event_id: null,
      detector_id: 'FVG_v1',
      symbol: SYMBOL,
      timeframe: tf,
      concept_family: 'Imbalances',
      concept_type: f.kind,
      concept_state: 'active',
      time_start: f.timeStart,
      time_end: f.timeEnd,
      price_high: f.priceHigh,
      price_low: f.priceLow,
      direction: f.direction,
      properties: JSON.stringify({ bar_index: f.idx, gap_size: f.priceHigh - f.priceLow })
    });
  }
  for (const o of obs) {
    events.push({
      event_id: eid('OB'),
      root_event_id: null,
      parent_event_id: null,
      detector_id: 'OB_v1',
      symbol: SYMBOL,
      timeframe: tf,
      concept_family: 'Order Flow',
      concept_type: 'OB',
      concept_state: 'active',
      time_start: o.timeStart,
      time_end: o.timeEnd,
      price_high: o.priceHigh,
      price_low: o.priceLow,
      direction: o.direction,
      properties: JSON.stringify({ bar_index: o.idx })
    });
  }
  return { events, swings: { highs, lows, all: allSwings } };
}

// ─── 7. Build liquidity objects (BSL above swing highs, SSL below lows) ────
// Only emit liquidity for degree-1 structural swings (the per-bar pivots).
// Higher-degree swings are derived abstractions, not liquidity resting places.
function buildLiquidity(swings, tf) {
  const out = [];
  let counter = 0;
  const deg1Highs = swings.highs.filter(h => !h.degree || h.degree === 1);
  const deg1Lows  = swings.lows.filter(l => !l.degree || l.degree === 1);
  for (const h of deg1Highs) {
    out.push({
      liquidity_id: `BSL_${RUN_ID}_${tf}_${counter++}`,
      parent_swing_id: h.id,
      price: h.price,
      parent_swing_type: 'high',
      liquidity_side: 'sell_side',
      swing_degree: 1,
      timeframe: tf,
      symbol: SYMBOL,
      origin_bar_index: h.idx,
      confirmation_bar_index: h.idx + 1,
      origin_timestamp: h.time,
      metadata: JSON.stringify({ type: 'BSL' })
    });
  }
  for (const l of deg1Lows) {
    out.push({
      liquidity_id: `SSL_${RUN_ID}_${tf}_${counter++}`,
      parent_swing_id: l.id,
      price: l.price,
      parent_swing_type: 'low',
      liquidity_side: 'buy_side',
      swing_degree: 1,
      timeframe: tf,
      symbol: SYMBOL,
      origin_bar_index: l.idx,
      confirmation_bar_index: l.idx + 1,
      origin_timestamp: l.time,
      metadata: JSON.stringify({ type: 'SSL' })
    });
  }
  return out;
}

// ─── 8. Write CSV for /api/symbols discovery ───────────────────────────────
function writeCSV(bars, filePath) {
  const lines = ['date,open,high,low,close,volume'];
  for (const b of bars) {
    const d = new Date(b.time * 1000);
    const pad = (n) => String(n).padStart(2, '0');
    const dateStr = `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}`;
    lines.push(`${dateStr},${b.open.toFixed(2)},${b.high.toFixed(2)},${b.low.toFixed(2)},${b.close.toFixed(2)},${b.volume}`);
  }
  fs.writeFileSync(filePath, lines.join('\n'));
  console.log(`[seed] Wrote ${bars.length} rows → ${filePath}`);
}

// ─── 9. Main ───────────────────────────────────────────────────────────────
async function main() {
  console.log(`[seed] Generating ${BARS_COUNT} synthetic 1-min bars for ${SYMBOL}...`);
  const bars1m = generateBars(BARS_COUNT);
  const bars5m = aggregate(bars1m, 5);
  const bars15m = aggregate(bars1m, 15);
  console.log(`[seed] Aggregated: ${bars1m.length} 1m, ${bars5m.length} 5m, ${bars15m.length} 15m`);

  // Write CSV (1m bars only — backend's parseCsvFile will load these)
  const dataDir = path.join(REPO, 'data');
  fs.mkdirSync(dataDir, { recursive: true });
  writeCSV(bars1m, path.join(dataDir, `${SYMBOL}.csv`));

  // Hook into PDOS DB layer
  process.chdir(REPO);
  const { getDB } = require(path.join(REPO, 'algo', 'db'));
  const RegistryService = require(path.join(REPO, 'algo', 'RegistryService'));
  const dbName = 'market_research_v2.db';
  const db = getDB(dbName);

  // Insert bars for 1m, 5m, 15m
  console.log('[seed] Inserting bars into market_bars...');
  db.prepare('DELETE FROM market_bars WHERE symbol = ?').run(SYMBOL);
  RegistryService.insertBars(dbName, SYMBOL, 1, bars1m);
  RegistryService.insertBars(dbName, SYMBOL, 5, bars5m);
  RegistryService.insertBars(dbName, SYMBOL, 15, bars15m);

  // Clear old run_dev events
  console.log('[seed] Clearing old structure_events / liquidity_objects for run_id=' + RUN_ID);
  db.prepare('DELETE FROM structure_events WHERE run_id = ?').run(RUN_ID);
  db.prepare('DELETE FROM liquidity_objects WHERE run_id = ?').run(RUN_ID);
  db.prepare('DELETE FROM event_outcomes WHERE run_id = ?').run(RUN_ID);

  // Make sure research_runs has the run_dev row
  const manifest = require(path.join(REPO, 'algo', 'EngineManifest'));
  db.prepare(`
    INSERT OR REPLACE INTO research_runs (run_id, workspace_id, symbol, status, config, versions, statistics, completed_at)
    VALUES (?, 'development', ?, 'completed', '{}', ?, ?, CURRENT_TIMESTAMP)
  `).run(
    RUN_ID,
    SYMBOL,
    JSON.stringify(manifest),
    JSON.stringify({ bars: bars1m.length, seeded_at: new Date().toISOString() })
  );

  // Build & insert events + liquidity per timeframe
  let totalEvents = 0, totalLiquidity = 0;
  for (const [tf, bars] of [[1, bars1m], [5, bars5m], [15, bars15m]]) {
    const { events, swings } = buildEvents(bars, tf);
    const liquidity = buildLiquidity(swings, tf);
    RegistryService.insertEvents(dbName, RUN_ID, events);
    RegistryService.insertLiquidityObjects(dbName, RUN_ID, liquidity);
    console.log(`[seed] tf=${tf}: ${events.length} events, ${liquidity.length} liquidity objects`);
    totalEvents += events.length;
    totalLiquidity += liquidity.length;
  }

  console.log(`\n[seed] DONE. Totals: ${totalEvents} events, ${totalLiquidity} liquidity objects across 3 timeframes.`);
  console.log(`[seed] SQLite DB: ${path.join(REPO, dbName)}`);
  console.log(`[seed] CSV file: ${path.join(dataDir, SYMBOL + '.csv')}`);
}

main().catch(err => {
  console.error('[seed] FATAL:', err);
  process.exit(1);
});
