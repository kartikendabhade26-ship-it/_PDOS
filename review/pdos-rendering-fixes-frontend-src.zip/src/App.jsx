import React, { useEffect, useRef, useState, useMemo } from 'react';
import { createChart, CrosshairMode, CandlestickSeries, BarSeries, LineSeries, HistogramSeries } from 'lightweight-charts';
import {
  MousePointer,
  TrendingUp,
  TrendingDown,
  Minus,
  ArrowUpRight,
  Type,
  Brush,
  Square,
  Compass,
  Magnet,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  Trash2,
  Undo2,
  Redo2,
  Settings,
  Layers,
  Check,
  ChevronDown,
  Activity,
  BarChart2,
  X,
  Sun,
  Moon,
  Play,
  Pause,
  SkipForward,
  SkipBack,
  History,

  ZoomIn,
  ZoomOut,
  ChevronLeft,
  ChevronRight,
  RefreshCw,
  GripVertical
} from 'lucide-react';


import ChartSettingsModal from './components/ChartSettingsModal';
import ChartViewport from './components/ChartViewport';
import WatchlistSidebar from './components/WatchlistSidebar';
import ValidationWorkspace from './components/ValidationWorkspace';
import ResearchWorkspace from './components/ResearchWorkspace';
import DiagnosticsWorkspace from './components/DiagnosticsWorkspace';

import { getESTInfo } from './utils/sessions';
import { aggregateDevelopingCandle } from './utils/replayAggregator';
import {
  saveDrawings,
  loadDrawings,
  savePreferences,
  loadPreferences
} from './utils/storage';

const CONCEPT_PRESETS = [
  { id: 'fvg_bullish',    label: 'FVG Bullish',          color: '#26a69a' },
  { id: 'fvg_bearish',    label: 'FVG Bearish',          color: '#ef5350' },
  { id: 'ifvg_bullish',   label: 'IFVG Bullish',         color: '#00e676' },
  { id: 'ifvg_bearish',   label: 'IFVG Bearish',         color: '#ff1744' },
  { id: 'ob_bullish',     label: 'Order Block Bullish',  color: '#00bcd4' },
  { id: 'ob_bearish',     label: 'Order Block Bearish',  color: '#ff9800' },
  { id: 'liquidity_bsl',  label: 'Buy Side Liquidity',   color: '#9c27b0' },
  { id: 'liquidity_ssl',  label: 'Sell Side Liquidity',  color: '#f44336' },
  { id: 'swing_bullish',  label: 'Swing Low (Bullish)',  color: '#26a69a' },
  { id: 'swing_bearish',  label: 'Swing High (Bearish)', color: '#ef5350' },
  { id: 'strong_swing_bullish',  label: 'Strong Swing Low',  color: '#00e676' },
  { id: 'strong_swing_bearish',  label: 'Strong Swing High', color: '#ff1744' },
  { id: 'premium_discount_premium',  label: 'Premium Zone',  color: '#ef5350' },
  { id: 'premium_discount_discount', label: 'Discount Zone', color: '#26a69a' },
  { id: 'mss_bullish',    label: 'MSS Bullish',          color: '#26a69a' },
  { id: 'mss_bearish',    label: 'MSS Bearish',          color: '#ef5350' },
  { id: 'bos_bullish',    label: 'BOS Bullish',          color: '#26a69a' },
  { id: 'bos_bearish',    label: 'BOS Bearish',          color: '#ef5350' },
  { id: 'protected_high_low_bullish',  label: 'Protected Low',  color: '#26a69a' },
  { id: 'protected_high_low_bearish',  label: 'Protected High', color: '#ef5350' },
  { id: 'volume_imbalance_bullish',    label: 'Vol Imbalance Bullish', color: '#26a69a' },
  { id: 'volume_imbalance_bearish',    label: 'Vol Imbalance Bearish', color: '#ef5350' },
  { id: 'liquidity_void_bullish',      label: 'Liq Void Bullish',      color: '#26a69a' },
  { id: 'liquidity_void_bearish',      label: 'Liq Void Bearish',      color: '#ef5350' },
  { id: 'amd_bullish',    label: 'AMD Bullish',          color: '#26a69a' },
  { id: 'amd_bearish',    label: 'AMD Bearish',          color: '#ef5350' }
];

const VALIDATION_CRITERIA = [
  { id: 'displacement', label: 'Strong Displacement (Impulse)' },
  { id: 'sweep',        label: 'Liquidity Sweep (Pre-sweep)' },
  { id: 'mss',          label: 'MSS / BOS (Structure Shift)' },
  { id: 'htf',          label: 'HTF Key Level (HTF Alignment)' },
  { id: 'reaction',     label: 'Price Reaction (Bounce/Hold)' }
];

const getVersionsForConcept = (conceptId) => {
  if (!conceptId) return [];
  if (conceptId.startsWith('ifvg')) {
    return ['Common IFVG', 'Mitigated BISI', 'Mitigated SIBI'];
  }
  if (conceptId.startsWith('fvg')) {
    return ['Common FVG', 'Breakaway Gap', 'Measuring Gap', 'Balanced Price Range (BPR)', 'Volume Imbalance'];
  }
  if (conceptId.startsWith('ob')) {
    return ['Standard OB', 'Breaker Block', 'Mitigation Block', 'Propulsion Block', 'Rejection Block'];
  }
  if (conceptId.startsWith('liquidity')) {
    return ['Equal Highs/Lows (EQH/L)', 'Trendline Liquidity', 'Swing High/Low', 'PDH/PDL'];
  }
  return [];
};

export default function App() {
  const containerRef = useRef(null);
  const chartRef = useRef(null);
  const seriesRef = useRef(null);
  const volumeRef = useRef(null);
  const chartTargetRef = useRef(null);

  // Data State
  const [symbols, setSymbols] = useState([]);
  const [activeSymbol, setActiveSymbol] = useState('');
  const [timeframe, setTimeframe] = useState(1); // minutes
  const [chartType, setChartType] = useState('candle');
  const [allBars, setAllBars] = useState([]);
  const [hudBar, setHudBar] = useState(null);

  // Drawing Tools State
  const [activeTool, setActiveTool] = useState(null);
  const [drawings, _setDrawings] = useState([]);

  // Default tool styles mapping (saved in local storage to remember drawing preferences)
  const [defaultToolStyles, setDefaultToolStyles] = useState(() => {
    try {
      const saved = localStorage.getItem('tv_default_tool_styles');
      return saved ? JSON.parse(saved) : {
        rectangle: { color: '#2962ff', width: 2, opacity: 0.15, lineStyle: 'solid' },
        trendline: { color: '#2962ff', width: 2, opacity: 1.0, lineStyle: 'solid' },
        'horizontal-line': { color: '#2962ff', width: 2, opacity: 1.0, lineStyle: 'solid' },
        ray: { color: '#2962ff', width: 2, opacity: 1.0, lineStyle: 'solid' },
        fibonacci: { color: '#787b86', width: 1, opacity: 1.0, lineStyle: 'solid' },
        brush: { color: '#2962ff', width: 2, opacity: 1.0, lineStyle: 'solid' },
        text: { color: '#ffffff', fontSize: 12, opacity: 1.0 },
        'position-long': { color: '#089981', width: 1.5, opacity: 1.0, lineStyle: 'solid' },
        'position-short': { color: '#f23645', width: 1.5, opacity: 1.0, lineStyle: 'solid' }
      };
    } catch (e) {
      return {
        rectangle: { color: '#2962ff', width: 2, opacity: 0.15, lineStyle: 'solid' },
        trendline: { color: '#2962ff', width: 2, opacity: 1.0, lineStyle: 'solid' },
        'horizontal-line': { color: '#2962ff', width: 2, opacity: 1.0, lineStyle: 'solid' },
        ray: { color: '#2962ff', width: 2, opacity: 1.0, lineStyle: 'solid' },
        fibonacci: { color: '#787b86', width: 1, opacity: 1.0, lineStyle: 'solid' },
        brush: { color: '#2962ff', width: 2, opacity: 1.0, lineStyle: 'solid' },
        text: { color: '#ffffff', fontSize: 12, opacity: 1.0 },
        'position-long': { color: '#089981', width: 1.5, opacity: 1.0, lineStyle: 'solid' },
        'position-short': { color: '#f23645', width: 1.5, opacity: 1.0, lineStyle: 'solid' }
      };
    }
  });

  const setDrawings = (newDrawingsOrFn) => {
    _setDrawings(prev => {
      const next = typeof newDrawingsOrFn === 'function' ? newDrawingsOrFn(prev) : newDrawingsOrFn;
      
      // Auto-remember drawing style preferences if they are changed
      if (prev.length === next.length) {
        for (let i = 0; i < prev.length; i++) {
          const p = prev[i];
          const n = next[i];
          if (p && n && p.id === n.id) {
            const styleKeys = [
              'color', 'width', 'opacity', 'lineStyle', 
              'textColor', 'textOpacity', 'fontSize', 'bold', 'italic', 'textHalign', 'textValign',
              'backgroundColor', 'backgroundOpacity', 'fillOpacity',
              'borderColor', 'borderWidth', 'borderOpacity', 'borderStyle',
              'extendLeft', 'extendRight', 'showAngle', 'showPriceLabel',
              'showMiddleLine', 'middleLineColor', 'middleLineWidth', 'middleLineStyle',
              'showAsTrade', 'tradeDirection'
            ];
            let changed = false;
            const updatedStyle = {};
            styleKeys.forEach(k => {
              if (p[k] !== n[k]) {
                changed = true;
                updatedStyle[k] = n[k];
              }
            });
            if (changed) {
              const toolType = n.type;
              if (toolType) {
                setDefaultToolStyles(d => {
                  const updated = {
                    ...d,
                    [toolType]: {
                      ...d[toolType],
                      ...updatedStyle
                    }
                  };
                  localStorage.setItem('tv_default_tool_styles', JSON.stringify(updated));
                  return updated;
                });
              }
              break;
            }
          }
        }
      }
      return next;
    });
  };
  const [selectedDrawing, setSelectedDrawing] = useState(null);
  const [floatingToolbarPos, setFloatingToolbarPos] = useState({ x: 100, y: 100 });
  const [isToolbarPinned, setIsToolbarPinned] = useState(false);
  const [isDrawingSettingsOpen, setIsDrawingSettingsOpen] = useState(false);

  // Undo/Redo Stacks
  const [undoStack, setUndoStack] = useState([]);
  const [redoStack, setRedoStack] = useState([]);

  // Preferences (Saved in LocalStorage)
  const [magnetMode, setMagnetMode] = useState(false);
  const [lockDrawings, setLockDrawings] = useState(false);
  const [hideDrawings, setHideDrawings] = useState(false);
  const [showSessions, setShowSessions] = useState(true);
  const [showVolume, setShowVolume] = useState(true);

  // Theme Mode
  const [isDarkMode, setIsDarkMode] = useState(() => {
    try {
      const saved = localStorage.getItem('tv_dark_mode');
      return saved ? JSON.parse(saved) : true;
    } catch (e) {
      return true;
    }
  });

  // Chart Settings state for customization modal
  const [chartSettings, setChartSettings] = useState(() => {
    try {
      const defaults = {
        showCandleBody: true,
        showCandleBorders: true,
        showCandleWicks: true,
        upColor: '#66bb6a',
        downColor: '#000000',
        borderUpColor: '#000000',
        borderDownColor: '#000000',
        wickUpColor: '#000000',
        wickDownColor: '#000000',
        showOhlc: true,
        showGridLines: true,
        gridColor: '',
        bgColor: '#d0d4de',
        textColor: '#000000',
      };

      const saved = localStorage.getItem('tv_chart_settings');
      if (saved) {
        const parsed = JSON.parse(saved);
        // Merge defaults with saved settings so new keys are backfilled, 
        // while preserving existing user changes.
        return { ...defaults, ...parsed };
      }

      localStorage.setItem('tv_chart_settings', JSON.stringify(defaults));
      return defaults;
    } catch (e) {
      return {
        showCandleBody: true,
        showCandleBorders: true,
        showCandleWicks: true,
        upColor: '#66bb6a',
        downColor: '#000000',
        borderUpColor: '#000000',
        borderDownColor: '#000000',
        wickUpColor: '#000000',
        wickDownColor: '#000000',
        showOhlc: true,
        showGridLines: true,
        gridColor: '',
        bgColor: '#d0d4de',
        textColor: '#000000',
      };
    }
  });

  useEffect(() => {
    localStorage.setItem('tv_chart_settings', JSON.stringify(chartSettings));
  }, [chartSettings]);

  // Settings Modal
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [themeColor, setThemeColor] = useState('#2962ff');

  // Workspace and View Mode States
  const [workspaceTab, setWorkspaceTab] = useState('chart'); // 'chart' | 'validation' | 'research' | 'diagnostics'
  const [debugOverlayFilters, setDebugOverlayFilters] = useState({
    swings: true,
    liquidity: true,
    structure: true,
    dealingRanges: true,
    takenLiqOpacity: 0.25   // alpha for taken (terminated) liquidity lines
  });

  // Algo Candidate select / zones display states
  const [selectedConcept, setSelectedConcept] = useState('');
  const [showAlgoZones, setShowAlgoZones] = useState(true); // default to true since Narrative Mode is active
  const [algoCandidates, setAlgoCandidates] = useState([]);
  const [algoCandidates2, setAlgoCandidates2] = useState([]);
  const [selectedAlgoCandidate, setSelectedAlgoCandidate] = useState(null);
  const [displayMode, setDisplayMode] = useState('default');
  const [narrativeMode, setNarrativeMode] = useState(true); // default to narrative mode
  const [narrativeFocusRangeId, setNarrativeFocusRangeId] = useState(null);
  const [viewMode, setViewMode] = useState('narrative');
  const [isLayersDropdownOpen, setIsLayersDropdownOpen] = useState(false);
  const [analysisLayers, setAnalysisLayers] = useState({
    swings: true,
    liquidity: true,
    structure: true,
    dealingRanges: true,
    intent: true,
    delivery: true
  });

  // Chart initialized callback indicator
  const [chartInitialized, setChartInitialized] = useState(false);
  
  // Right sidebar tab: 'market' | 'research' | 'chat'
  const [rightSidebarTab, setRightSidebarTab] = useState('market');

  const [replayMode, setReplayMode] = useState(false);
  const [replayTimeOffset, setReplayTimeOffset] = useState(null);
  const [replayIndex, setReplayIndex] = useState(0);
  const [replaySpeed, setReplaySpeed] = useState(1000); // ms per advance
  const [isReplayPlaying, setIsReplayPlaying] = useState(false);
  const replayTimerRef = useRef(null);
  const lastReplayTimeRef = useRef((() => {
    const saved = localStorage.getItem('tv_last_replay_time');
    if (!saved) return null;
    return /^\d+$/.test(saved) ? parseInt(saved, 10) : saved;
  })());
  const forceViewportResetRef = useRef(true);

  // --- SUB-CANDLE REPLAY STATES ---
  const [replayTimeframeOption, setReplayTimeframeOption] = useState('1m');
  const [isTimeframeDropdownOpen, setIsTimeframeDropdownOpen] = useState(false);
  const [currentBarStates, setCurrentBarStates] = useState([]);
  const [currentSubStep, setCurrentSubStep] = useState(0);

  // --- DUAL TIMEFRAME SPLIT LAYOUT STATES ---
  const [layout, setLayout] = useState('single');
  const [timeframe2, setTimeframe2] = useState(15);
  const [allBars2, setAllBars2] = useState([]);

  const [loadingState1, setLoadingState1] = useState({ candles: false, events: false });
  const [loadingState2, setLoadingState2] = useState({ candles: false, events: false });

  const container2Ref = useRef(null);
  const chart2Ref = useRef(null);
  const series2Ref = useRef(null);
  const volume2Ref = useRef(null);
  const chartTarget2Ref = useRef(null);

  const [replayToolbarPos, setReplayToolbarPos] = useState(() => {
    return { x: Math.max(100, window.innerWidth / 2 - 200), y: Math.max(100, window.innerHeight - 110) };
  });
  const [isReplayDragging, setIsReplayDragging] = useState(false);
  const replayDragStartRef = useRef({ x: 0, y: 0 });

  const handleReplayDragStart = (e) => {
    if (e.target.closest('button') || e.target.closest('input') || e.target.closest('select') || e.target.closest('.replay-switch')) return;
    e.preventDefault();
    setIsReplayDragging(true);
    replayDragStartRef.current = {
      x: e.clientX - replayToolbarPos.x,
      y: e.clientY - replayToolbarPos.y
    };
  };

  useEffect(() => {
    const handleMouseMove = (e) => {
      if (!isReplayDragging) return;
      setReplayToolbarPos({
        x: e.clientX - replayDragStartRef.current.x,
        y: e.clientY - replayDragStartRef.current.y
      });
    };

    const handleMouseUp = () => {
      setIsReplayDragging(false);
    };

    if (isReplayDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isReplayDragging]);

  const getReplayStepSeconds = (opt) => {
    if (opt.endsWith('s')) {
      return parseInt(opt, 10);
    }
    if (opt.endsWith('m')) {
      return parseInt(opt, 10) * 60;
    }
    return 60;
  };

  const generateSubCandleStates = (bar, N) => {
    const states = [];
    const isBullish = bar.close >= bar.open;
    const firstExtreme = isBullish ? bar.low : bar.high;
    const secondExtreme = isBullish ? bar.high : bar.low;
    
    for (let i = 1; i <= N; i++) {
      const pct = i / N;
      let currentClose = bar.open;
      let currentHigh = bar.open;
      let currentLow = bar.open;
      
      if (N <= 1) {
        currentClose = bar.close;
        currentHigh = bar.high;
        currentLow = bar.low;
      } else {
        if (pct <= 0.33) {
          const t = pct / 0.33;
          currentClose = bar.open + (firstExtreme - bar.open) * t;
        } else if (pct <= 0.66) {
          const t = (pct - 0.33) / 0.33;
          currentClose = firstExtreme + (secondExtreme - firstExtreme) * t;
        } else {
          const t = (pct - 0.66) / 0.34;
          currentClose = secondExtreme + (bar.close - secondExtreme) * t;
        }
        
        if (pct <= 0.33) {
          currentHigh = Math.max(bar.open, currentClose);
          currentLow = Math.min(bar.open, currentClose);
        } else if (pct <= 0.66) {
          currentHigh = Math.max(bar.open, firstExtreme, currentClose);
          currentLow = Math.min(bar.open, firstExtreme, currentClose);
        } else {
          currentHigh = Math.max(bar.open, firstExtreme, secondExtreme, currentClose);
          currentLow = Math.min(bar.open, firstExtreme, secondExtreme, currentClose);
        }
        
        if (i < N) {
          const wobble = (Math.random() - 0.5) * (bar.high - bar.low) * 0.03;
          currentClose += wobble;
          currentHigh = Math.max(currentHigh, currentClose);
          currentLow = Math.min(currentLow, currentClose);
        } else {
          currentClose = bar.close;
          currentHigh = bar.high;
          currentLow = bar.low;
        }
      }
      
      states.push({
        time: bar.time,
        open: bar.open,
        high: currentHigh,
        low: currentLow,
        close: currentClose,
        volume: Math.round(bar.volume * pct)
      });
    }
    return states;
  };


  // Replay sub-candle states sync hook
  useEffect(() => {
    if (replayMode && allBars.length > 0 && allBars[replayIndex - 1]) {
      const chartTfSec = timeframe * 60;
      const stepSec = getReplayStepSeconds(replayTimeframeOption);
      if (stepSec < chartTfSec) {
        const N = Math.round(chartTfSec / stepSec);
        const curBar = allBars[replayIndex - 1];
        const states = generateSubCandleStates(curBar, N);
        setCurrentBarStates(states);
        if (currentSubStep >= states.length) {
          setCurrentSubStep(states.length - 1);
        }
      } else {
        setCurrentBarStates([]);
        setCurrentSubStep(0);
      }
    } else {
      setCurrentBarStates([]);
      setCurrentSubStep(0);
    }
  }, [replayIndex, replayMode, timeframe, replayTimeframeOption, allBars]);



  // Track last replay timestamp to survive timeframe and symbol changes, and page reloads
  useEffect(() => {
    if (replayMode && replayIndex > 0 && allBars[replayIndex - 1]) {
      const t = allBars[replayIndex - 1].time;
      lastReplayTimeRef.current = t;
      localStorage.setItem('tv_last_replay_time', String(t));
    }
  }, [replayIndex, replayMode, allBars]);

  const lastViewSymbolRef = useRef('');
  const lastViewTimeframeRef = useRef(0);
  const lastViewReplayModeRef = useRef(false);

  const checkAndResetViewportChange = () => {
    const symbolChanged = lastViewSymbolRef.current !== activeSymbol;
    const timeframeChanged = lastViewTimeframeRef.current !== timeframe;
    const replayModeToggled = lastViewReplayModeRef.current !== replayMode;
    const forcedReset = forceViewportResetRef.current;

    lastViewSymbolRef.current = activeSymbol;
    lastViewTimeframeRef.current = timeframe;
    lastViewReplayModeRef.current = replayMode;

    if (forcedReset) {
      forceViewportResetRef.current = false;
    }

    return symbolChanged || timeframeChanged || replayModeToggled || forcedReset;
  };

  // --- CONTINUOUS ACTION HANDLER FOR ZOOM/SCROLL ---
  const startContinuousAction = (e, actionFn) => {
    if (e.button !== 0 && e.type === 'mousedown') return; // only left click
    e.preventDefault();
    actionFn();
    
    // Delay before repeating starts
    const timeoutId = setTimeout(() => {
      const intervalId = setInterval(actionFn, 50);
      const stop = () => {
        clearInterval(intervalId);
        window.removeEventListener('mouseup', stop);
        window.removeEventListener('touchend', stop);
      };
      window.addEventListener('mouseup', stop);
      window.addEventListener('touchend', stop);
    }, 250);

    const stopImmediate = () => {
      clearTimeout(timeoutId);
      window.removeEventListener('mouseup', stopImmediate);
      window.removeEventListener('touchend', stopImmediate);
    };
    window.addEventListener('mouseup', stopImmediate);
    window.addEventListener('touchend', stopImmediate);
  };

  // --- STARTUP: Load symbols & settings ---
  useEffect(() => {
    // Restore saved replay mode if possible, respecting active session status
    const savedSession = localStorage.getItem('tv_backtest_session');
    const savedReplayMode = localStorage.getItem('tv_replay_mode');
    if (savedSession) {
      if (savedReplayMode === 'false') {
        setReplayMode(false);
      } else {
        setReplayMode(true);
      }
    } else {
      setReplayMode(savedReplayMode === 'true');
    }

    // Load preferences
    const prefs = loadPreferences();
    setMagnetMode(prefs.magnetMode);
    setLockDrawings(prefs.lockDrawings);
    setShowSessions(prefs.showSessions !== undefined ? prefs.showSessions : true);

    // Fetch symbols with retry
    const fetchSymbols = (retriesLeft = 15) => {
      fetch('http://localhost:8080/api/symbols')
        .then(res => res.json())
        .then(data => {
          setSymbols(data);
          if (data.length > 0) {
            // Check if there's a last used symbol, or default to first
            const savedSymbol = localStorage.getItem('tv_last_symbol');
            const defaultSym = data.includes(savedSymbol) ? savedSymbol : data[0];
            setActiveSymbol(defaultSym);
          }
        })
        .catch(err => {
          console.error(`Error loading symbols from backend (retries left: ${retriesLeft}): `, err);
          if (retriesLeft > 0) {
            setTimeout(() => fetchSymbols(retriesLeft - 1), 2000);
          }
        });
    };
    fetchSymbols();




    // Sync default tool styles when modified externally (e.g. from modal settings dropdown)
    const handleDefaultsChanged = () => {
      try {
        const saved = localStorage.getItem('tv_default_tool_styles');
        if (saved) {
          setDefaultToolStyles(JSON.parse(saved));
        }
      } catch (e) {
        console.error(e);
      }
    };
    window.addEventListener('tv_default_styles_changed', handleDefaultsChanged);
    return () => {
      window.removeEventListener('tv_default_styles_changed', handleDefaultsChanged);
    };
  }, []);


  // --- ALGO CANDIDATES DATA FETCHING & SYNCHRONIZATION ---
  useEffect(() => {
    if (!activeSymbol) {
      setAlgoCandidates([]);
      setSelectedAlgoCandidate(null);
      return;
    }

    setLoadingState1(prev => ({ ...prev, events: true }));

    const conceptParam = '';
    const limit = 15000;

    // When a replay time offset is set, fetch events only for the loaded window.
    // This avoids loading 17 months of events when we only need a specific slice.
    let eventsUrl;
    if (replayTimeOffset) {
      const tfSec = timeframe * 60;
      const startSec = replayTimeOffset - 8000 * tfSec;
      const endSec   = replayTimeOffset + 500  * tfSec;
      eventsUrl = `http://localhost:8080/api/events?symbol=${activeSymbol}&timeframe=${timeframe}&concept=${conceptParam}&limit=${limit}&display_mode=${displayMode}&start=${startSec}&end=${endSec}`;
    } else {
      eventsUrl = `http://localhost:8080/api/events?symbol=${activeSymbol}&timeframe=${timeframe}&concept=${conceptParam}&limit=${limit}&display_mode=${displayMode}`;
    }

    fetch(eventsUrl)
      .then(res => res.json())
      .then(data => {
        setAlgoCandidates(data || []);
        setLoadingState1(prev => ({ ...prev, events: false }));
      })
      .catch(err => {
        console.error("Error fetching algo events:", err);
        setLoadingState1(prev => ({ ...prev, events: false }));
      });

    setSelectedAlgoCandidate(null);
  }, [activeSymbol, timeframe, displayMode, replayTimeOffset]);

  // --- ALGO CANDIDATES DATA FETCHING & SYNCHRONIZATION FOR CHART 2 ---
  useEffect(() => {
    if (!activeSymbol || layout !== 'split') {
      setAlgoCandidates2([]);
      return;
    }

    setLoadingState2(prev => ({ ...prev, events: true }));

    const conceptParam = '';
    const limit = 15000;

    let eventsUrl;
    if (replayTimeOffset) {
      const tfSec = timeframe2 * 60;
      const startSec = replayTimeOffset - 8000 * tfSec;
      const endSec   = replayTimeOffset + 500  * tfSec;
      eventsUrl = `http://localhost:8080/api/events?symbol=${activeSymbol}&timeframe=${timeframe2}&concept=${conceptParam}&limit=${limit}&display_mode=${displayMode}&start=${startSec}&end=${endSec}`;
    } else {
      eventsUrl = `http://localhost:8080/api/events?symbol=${activeSymbol}&timeframe=${timeframe2}&concept=${conceptParam}&limit=${limit}&display_mode=${displayMode}`;
    }

    fetch(eventsUrl)
      .then(res => res.json())
      .then(data => {
        setAlgoCandidates2(data || []);
        setLoadingState2(prev => ({ ...prev, events: false }));
      })
      .catch(err => {
        console.error("Error fetching secondary algo events:", err);
        setLoadingState2(prev => ({ ...prev, events: false }));
      });
  }, [activeSymbol, timeframe2, layout, displayMode, replayTimeOffset]);

  // Upstream candidates filtering - ensures each chart only renders events belonging to its exact symbol and timeframe
  const filteredAlgoCandidates = useMemo(() => {
    const targetTf = Number(timeframe);
    const targetSymbol = activeSymbol ? activeSymbol.toLowerCase() : '';
    return algoCandidates.filter(c => 
      Number(c.timeframe) === targetTf && 
      (!c.symbol || !targetSymbol || c.symbol.toLowerCase() === targetSymbol)
    );
  }, [algoCandidates, timeframe, activeSymbol]);

  const filteredAlgoCandidates2 = useMemo(() => {
    const targetTf = Number(timeframe2);
    const targetSymbol = activeSymbol ? activeSymbol.toLowerCase() : '';
    return algoCandidates2.filter(c => 
      Number(c.timeframe) === targetTf && 
      (!c.symbol || !targetSymbol || c.symbol.toLowerCase() === targetSymbol)
    );
  }, [algoCandidates2, timeframe2, activeSymbol]);

  // Jump to specific timestamp and auto-center
  const handleJumpToTime = (timestamp) => {
    if (!chartRef.current || allBars.length === 0) return;
    const timeScale = chartRef.current.timeScale();
    const idx = allBars.findIndex(b => b.time >= timestamp);
    if (idx !== -1) {
      if (replayMode) {
        setReplayIndex(idx + 1);
        setCurrentSubStep(0);
      }
      chartRef.current.priceScale('right').applyOptions({ autoScale: true });
      setTimeout(() => {
        const width = 150;
        const margin = 50;
        timeScale.setVisibleLogicalRange({
          from: idx - (width - margin),
          to: idx + margin
        });
      }, 50);
    }
  };

  // Scroll viewport when selectedAlgoCandidate changes
  useEffect(() => {
    if (chartRef.current && selectedAlgoCandidate && allBars.length > 0) {
      setTimeout(() => {
        if (!chartRef.current) return;
        const timeScale = chartRef.current.timeScale();
        timeScale.setVisibleRange({
          from: selectedAlgoCandidate.time - 45 * (timeframe * 60),
          to: selectedAlgoCandidate.time + 30 * (timeframe * 60)
        });
      }, 80);
    }
  }, [selectedAlgoCandidate, allBars, timeframe]);

  // Save validation status
  const saveExplorerLabel = async (status, notes) => {
    if (!selectedAlgoCandidate) return;
    const cand = selectedAlgoCandidate;

    try {
      const res = await fetch(`http://localhost:8080/api/validations`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ eventId: cand.id, status, notes })
      });
      if (!res.ok) throw new Error(await res.text());

      // Update local state in place
      const updatedValidation = { status, notes };
      setAlgoCandidates(prev => prev.map(c => c.id === cand.id ? { ...c, validation: updatedValidation } : c));
      setSelectedAlgoCandidate(prev => prev && prev.id === cand.id ? { ...prev, validation: updatedValidation } : prev);
    } catch (err) {
      console.error("Error saving validation:", err);
      alert("Error saving validation: " + err.message);
    }
  };

  // Save preferences on state change
  useEffect(() => {
    savePreferences({
      magnetMode,
      lockDrawings,
      showSessions
    });
  }, [magnetMode, lockDrawings, showSessions]);

  useEffect(() => {
    localStorage.setItem('tv_dark_mode', JSON.stringify(isDarkMode));
    if (isDarkMode) {
      document.body.classList.add('dark-theme');
    } else {
      document.body.classList.remove('dark-theme');
    }
  }, [isDarkMode]);

  // Sync chart options when isDarkMode, chartSettings, or chartInitialized changes
  useEffect(() => {
    if (chartRef.current) {
      const gridColor = chartSettings.showGridLines
        ? (chartSettings.gridColor || (isDarkMode ? '#2a2e39' : '#e1e4eb'))
        : 'transparent';
      const bgColor = chartSettings.bgColor || (isDarkMode ? '#131722' : '#f0f3fa');

      chartRef.current.applyOptions({
        layout: {
          background: { color: bgColor },
          textColor: chartSettings.textColor || (isDarkMode ? '#b2b5be' : '#70737d'),
        },
        grid: {
          vertLines: { color: gridColor, visible: chartSettings.showGridLines },
          horzLines: { color: gridColor, visible: chartSettings.showGridLines },
        },
        rightPriceScale: {
          borderColor: isDarkMode ? '#2a2e39' : '#d1d4dc',
        },
        timeScale: {
          borderColor: isDarkMode ? '#2a2e39' : '#d1d4dc',
        }
      });
    }
  }, [isDarkMode, chartSettings, chartInitialized]);

  // Load drawings whenever activeSymbol changes
  useEffect(() => {
    if (activeSymbol) {
      localStorage.setItem('tv_last_symbol', activeSymbol);
      const loaded = loadDrawings(activeSymbol).map((d, index) => ({
        ...d,
        id: d.id || `draw_${Date.now()}_${index}_${Math.random().toString(36).substring(2, 9)}`,
        lineStyle: d.lineStyle || 'solid'
      }));
      setDrawings(loaded);
      setSelectedDrawing(null);
      setUndoStack([]);
      setRedoStack([]);
    }
  }, [activeSymbol]);

  // Save drawings whenever drawings changes (debounced)
  useEffect(() => {
    if (activeSymbol) {
      const timeoutId = setTimeout(() => {
        saveDrawings(activeSymbol, drawings);
      }, 500);
      return () => clearTimeout(timeoutId);
    }
  }, [drawings, activeSymbol]);

  // --- FETCH MNQ CANDLESTICK DATA FOR CHART 1 ---
  useEffect(() => {
    if (!activeSymbol) return;
    const controller = new AbortController();
    const signal = controller.signal;

    setLoadingState1(prev => ({ ...prev, candles: true }));

    // Capture replayTimeOffset in a local variable so the .then() closure
    // always sees the correct value (avoids stale closure bugs).
    const capturedOffset = replayTimeOffset;

    // When a replay time offset is set (replay started or date jumped),
    // load a window of bars centered on that timestamp so history is visible.
    let url;
    if (capturedOffset) {
      const tfSec = timeframe * 60;
      // Load 8000 bars of history before the replay point, 500 bars after
      const startSec = capturedOffset - 8000 * tfSec;
      const endSec   = capturedOffset + 500  * tfSec;
      url = `http://localhost:8080/api/data?symbol=${activeSymbol}&timeframe=${timeframe}&start=${startSec}&end=${endSec}&limit=10000`;
    } else {
      url = `http://localhost:8080/api/data?symbol=${activeSymbol}&timeframe=${timeframe}&limit=10000`;
    }

    // Load data from Node server
    fetch(url, { signal })
      .then(res => res.json())
      .then(data => {
        // Pre-compute EST sessions once to prevent massive lag during 60fps rendering
        for (let i = 0; i < data.length; i++) {
          const est = getESTInfo(data[i].time);
          data[i].estSession = est.session;
          data[i].isMidnightOpen = est.isMidnightOpen;
          data[i].isNewsOpen = est.isNewsOpen;
        }

        setAllBars(data);
        setHudBar(null);

        // If we loaded a windowed dataset for replay, find and set the replay index.
        if (capturedOffset) {
          let targetIndex = data.findIndex(b => b.time >= capturedOffset);
          if (targetIndex === -1) targetIndex = Math.max(0, data.length - 201);
          targetIndex = Math.max(50, targetIndex);
          setReplayIndex(targetIndex + 1);
          forceViewportResetRef.current = true;
        }
        setLoadingState1(prev => ({ ...prev, candles: false }));
      })
      .catch(err => {
        if (err.name === 'AbortError') return;
        console.error('Error loading chart data: ', err);
        setLoadingState1(prev => ({ ...prev, candles: false }));
      });

    return () => {
      controller.abort();
    };
  }, [activeSymbol, timeframe, chartInitialized, replayTimeOffset]);

  // --- INITIALIZE LIGHTWEIGHT CHART ---
  useEffect(() => {
    if (!chartTargetRef.current) return;

    // Clear target container to avoid duplication on React StrictMode dual-mounts
    chartTargetRef.current.innerHTML = '';

    // Create chart instance
    const gridColor = chartSettings.showGridLines
      ? (chartSettings.gridColor || (isDarkMode ? '#2a2e39' : '#e1e4eb'))
      : 'transparent';

    const chart = createChart(chartTargetRef.current, {
      layout: {
        background: { color: chartSettings.bgColor || (isDarkMode ? '#131722' : '#f0f3fa') },
        textColor: chartSettings.textColor || (isDarkMode ? '#b2b5be' : '#70737d'),
        fontFamily: "'Outfit', sans-serif",
        fontSize: 11,
      },
      grid: {
        vertLines: { color: gridColor, visible: chartSettings.showGridLines },
        horzLines: { color: gridColor, visible: chartSettings.showGridLines },
      },
      crosshair: {
        mode: CrosshairMode.Normal,
        vertLine: {
          visible: false,
          labelVisible: false,
        },
        horzLine: {
          visible: false,
          labelVisible: false,
        },
      },
      rightPriceScale: {
        borderColor: isDarkMode ? '#2a2e39' : '#d1d4dc',
        scaleMargins: { top: 0.08, bottom: 0.2 },
      },
      timeScale: {
        borderColor: isDarkMode ? '#2a2e39' : '#d1d4dc',
        timeVisible: true,
        secondsVisible: false,
      },
      handleScroll: { mouseWheel: true, pressedMouseMove: true },
      handleScale: { mouseWheel: true, pinch: true, axisPressedMouseMove: true },
    });

    chartRef.current = chart;

    // Add Volume pane at the bottom
    const volumeSeries = chart.addSeries(HistogramSeries, {
      color: 'rgba(38, 166, 154, 0.3)',
      priceFormat: { type: 'volume' },
      priceScaleId: 'volume',
    });
    chart.priceScale('volume').applyOptions({
      scaleMargins: { top: 0.8, bottom: 0 },
    });
    volumeRef.current = volumeSeries;

    // Subscribe to crosshair move for HUD OHLCV
    chart.subscribeCrosshairMove((param) => {
      if (!param.time) {
        setHudBar(null);
        return;
      }
      
      const bars = allBarsRef.current;
      if (!bars || bars.length === 0) return;

      // Find matching bar
      const bar = bars.find(b => b.time === param.time);
      if (bar) {
        // Calculate price diff/change
        const chg = bar.close - bar.open;
        const pct = ((chg / bar.open) * 100).toFixed(2);
        setHudBar({
          ...bar,
          change: chg,
          percent: pct
        });
      }
    });



    // Resize observer to handle container size changes dynamically (essential for flex/grid layouts)
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        if (width > 0 && height > 0 && chartRef.current) {
          try {
            chart.resize(width, height);
          } catch (e) {
            console.error("Error resizing chart:", e);
          }
        }
      }
    });

    if (chartTargetRef.current) {
      resizeObserver.observe(chartTargetRef.current);
    }

    setChartInitialized(true);

    return () => {
      resizeObserver.disconnect();
      if (chartRef.current) {
        try {
          chart.remove();
        } catch (e) {
          console.error("Error removing chart:", e);
        }
        chartRef.current = null;
      }
      seriesRef.current = null;
      volumeRef.current = null;
      setChartInitialized(false);
    };
  }, []);

  // --- FETCH SECONDARY CANDLESTICK DATA FOR SPLIT LAYOUT ---
  useEffect(() => {
    if (!activeSymbol || layout !== 'split') return;
    const controller = new AbortController();
    const signal = controller.signal;

    setLoadingState2(prev => ({ ...prev, candles: true }));

    let url = `http://localhost:8080/api/data?symbol=${activeSymbol}&timeframe=${timeframe2}&limit=10000`;

    fetch(url, { signal })
      .then(res => res.json())
      .then(data => {
        for(let i=0; i < data.length; i++) {
          const est = getESTInfo(data[i].time);
          data[i].estSession = est.session;
          data[i].isMidnightOpen = est.isMidnightOpen;
          data[i].isNewsOpen = est.isNewsOpen;
        }
        setAllBars2(data);
        setLoadingState2(prev => ({ ...prev, candles: false }));
      })
      .catch(err => {
        if (err.name === 'AbortError') return;
        console.error("Error loading secondary chart data: ", err);
        setLoadingState2(prev => ({ ...prev, candles: false }));
      });

    return () => {
      controller.abort();
    };
  }, [activeSymbol, timeframe2, layout]);

  const [chart2Initialized, setChart2Initialized] = useState(false);
  const [series2UpdateTick, setSeries2UpdateTick] = useState(0);
  const chart2InitPendingRef = useRef(false);
  const [chart2MountTick, setChart2MountTick] = useState(0);

  // Deferred chart2 init trigger: when layout switches to 'split', the DOM container
  // renders on the next frame. We use a mount-tick state to re-trigger init.
  useEffect(() => {
    if (layout === 'split' && chart2InitPendingRef.current && chartTarget2Ref.current) {
      setChart2MountTick(t => t + 1); // Trigger re-render so init effect can proceed
    }
  }); // No dep array — runs after every render until pending is cleared

  // --- INITIALIZE SECONDARY CHART ---
  // We need a two-phase init: first render the DOM container (layout='split'),
  // then on next tick the ref is populated and we can call createChart().
  useEffect(() => {
    // When leaving split mode, destroy chart 2
    if (layout !== 'split') {
      if (chart2Ref.current) {
        try { chart2Ref.current.remove(); } catch (e) {}
        chart2Ref.current = null;
        series2Ref.current = null;
        volume2Ref.current = null;
        chart2InitPendingRef.current = false;
        setChart2Initialized(false);
      }
      return;
    }

    // DOM not ready yet — schedule deferred init
    if (!chartTarget2Ref.current) {
      chart2InitPendingRef.current = true;
      return;
    }

    // Already initialized for this layout session — apply theme changes only
    if (chart2Ref.current && !chart2InitPendingRef.current) {
      const gridColor = chartSettings.showGridLines
        ? (chartSettings.gridColor || (isDarkMode ? '#2a2e39' : '#e1e4eb'))
        : 'transparent';
      chart2Ref.current.applyOptions({
        layout: {
          background: { color: chartSettings.bgColor || (isDarkMode ? '#131722' : '#f0f3fa') },
          textColor: chartSettings.textColor || (isDarkMode ? '#b2b5be' : '#70737d'),
        },
        grid: {
          vertLines: { color: gridColor, visible: chartSettings.showGridLines },
          horzLines: { color: gridColor, visible: chartSettings.showGridLines },
        },
        rightPriceScale: { borderColor: isDarkMode ? '#2a2e39' : '#d1d4dc' },
        timeScale: { borderColor: isDarkMode ? '#2a2e39' : '#d1d4dc' },
      });
      return;
    }

    chartTarget2Ref.current.innerHTML = '';
    const gridColor = chartSettings.showGridLines
      ? (chartSettings.gridColor || (isDarkMode ? '#2a2e39' : '#e1e4eb'))
      : 'transparent';

    const chart2 = createChart(chartTarget2Ref.current, {
      layout: {
        background: { color: chartSettings.bgColor || (isDarkMode ? '#131722' : '#f0f3fa') },
        textColor: chartSettings.textColor || (isDarkMode ? '#b2b5be' : '#70737d'),
        fontFamily: "'Outfit', sans-serif",
        fontSize: 11,
      },
      grid: {
        vertLines: { color: gridColor, visible: chartSettings.showGridLines },
        horzLines: { color: gridColor, visible: chartSettings.showGridLines },
      },
      crosshair: {
        mode: CrosshairMode.Normal,
        vertLine: { visible: false, labelVisible: false },
        horzLine: { visible: false, labelVisible: false },
      },
      rightPriceScale: {
        borderColor: isDarkMode ? '#2a2e39' : '#d1d4dc',
        scaleMargins: { top: 0.08, bottom: 0.2 },
      },
      timeScale: {
        borderColor: isDarkMode ? '#2a2e39' : '#d1d4dc',
        timeVisible: true,
        secondsVisible: false,
      },
      handleScroll: { mouseWheel: true, pressedMouseMove: true },
      handleScale: { mouseWheel: true, pinch: true, axisPressedMouseMove: true },
    });

    chart2Ref.current = chart2;

    const volumeSeries2 = chart2.addSeries(HistogramSeries, {
      color: 'rgba(38, 166, 154, 0.3)',
      priceFormat: { type: 'volume' },
      priceScaleId: 'volume',
    });
    chart2.priceScale('volume').applyOptions({
      scaleMargins: { top: 0.8, bottom: 0 },
    });
    volume2Ref.current = volumeSeries2;

    const resizeObserver2 = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        if (width > 0 && height > 0 && chart2Ref.current) {
          try {
            chart2Ref.current.resize(width, height);
          } catch (e) {
            console.error("Error resizing chart 2:", e);
          }
        }
      }
    });

    if (container2Ref.current) {
      resizeObserver2.observe(container2Ref.current);
    }

    chart2InitPendingRef.current = false;
    setChart2Initialized(true);

    return () => {
      resizeObserver2.disconnect();
      if (chart2Ref.current) {
        try {
          chart2Ref.current.remove();
        } catch (e) {}
        chart2Ref.current = null;
        series2Ref.current = null;
        volume2Ref.current = null;
        setChart2Initialized(false);
      }
    };
  }, [layout, isDarkMode, chartSettings, chart2MountTick]);

  // --- TIME SCALE RANGE SYNCHRONIZATION ---
  const isSyncingRef = useRef(false);
  useEffect(() => {
    if (!chartInitialized || !chart2Initialized || !chartRef.current || !chart2Ref.current) return;

    const timeScale1 = chartRef.current.timeScale();
    const timeScale2 = chart2Ref.current.timeScale();

    const handleRangeChange1 = () => {
      if (isSyncingRef.current) return;
      isSyncingRef.current = true;
      try {
        const range = timeScale1.getVisibleRange();
        if (range && range.from !== null && range.to !== null) {
          timeScale2.setVisibleRange(range);
        }
      } catch (e) {}
      isSyncingRef.current = false;
    };

    const handleRangeChange2 = () => {
      if (isSyncingRef.current) return;
      isSyncingRef.current = true;
      try {
        const range = timeScale2.getVisibleRange();
        if (range && range.from !== null && range.to !== null) {
          timeScale1.setVisibleRange(range);
        }
      } catch (e) {}
      isSyncingRef.current = false;
    };

    timeScale1.subscribeVisibleTimeRangeChange(handleRangeChange1);
    timeScale2.subscribeVisibleTimeRangeChange(handleRangeChange2);

    return () => {
      try {
        timeScale1.unsubscribeVisibleTimeRangeChange(handleRangeChange1);
      } catch (e) {}
      try {
        timeScale2.unsubscribeVisibleTimeRangeChange(handleRangeChange2);
      } catch (e) {}
    };
  }, [chartInitialized, chart2Initialized]);

  // --- REBUILD OR UPDATE CHART 2 SERIES ---
  const updateChart2Data = (bars) => {
    const chart2 = chart2Ref.current;
    if (!chart2) return;

    let displayBars = bars;
    if (replayMode) {
      const currentBar = allBars[replayIndex - 1];
      if (currentBar) {
        displayBars = aggregateDevelopingCandle(bars, allBars, timeframe2, currentBar.time);
      }
    }

    if (!series2Ref.current) {
      const upColor = chartSettings.showCandleBody ? (chartSettings.upColor || '#089981') : 'transparent';
      const downColor = chartSettings.showCandleBody ? (chartSettings.downColor || (isDarkMode ? '#f23645' : '#131722')) : 'transparent';
      const borderUpColor = chartSettings.showCandleBorders ? (chartSettings.borderUpColor || chartSettings.upColor || '#089981') : 'transparent';
      const borderDownColor = chartSettings.showCandleBorders ? (chartSettings.borderDownColor || chartSettings.downColor || (isDarkMode ? '#f23645' : '#131722')) : 'transparent';
      const wickUpColor = chartSettings.showCandleWicks ? (chartSettings.wickUpColor || chartSettings.upColor || '#089981') : 'transparent';
      const wickDownColor = chartSettings.showCandleWicks ? (chartSettings.wickDownColor || chartSettings.downColor || (isDarkMode ? '#f23645' : '#131722')) : 'transparent';

      if (chartType === 'candle') {
        series2Ref.current = chart2.addSeries(CandlestickSeries, {
          upColor,
          downColor,
          wickVisible: chartSettings.showCandleWicks,
          borderVisible: chartSettings.showCandleBorders,
          borderUpColor,
          borderDownColor,
          wickUpColor,
          wickDownColor,
        });
      } else if (chartType === 'bar') {
        series2Ref.current = chart2.addSeries(BarSeries, { upColor, downColor });
      } else {
        series2Ref.current = chart2.addSeries(LineSeries, { color: themeColor, lineWidth: 2 });
      }
      setSeries2UpdateTick(t => t + 1);
    } else {
      if (chartType === 'candle') {
        const upColor = chartSettings.showCandleBody ? (chartSettings.upColor || '#089981') : 'transparent';
        const downColor = chartSettings.showCandleBody ? (chartSettings.downColor || (isDarkMode ? '#f23645' : '#131722')) : 'transparent';
        const borderUpColor = chartSettings.showCandleBorders ? (chartSettings.borderUpColor || chartSettings.upColor || '#089981') : 'transparent';
        const borderDownColor = chartSettings.showCandleBorders ? (chartSettings.borderDownColor || chartSettings.downColor || (isDarkMode ? '#f23645' : '#131722')) : 'transparent';
        const wickUpColor = chartSettings.showCandleWicks ? (chartSettings.wickUpColor || chartSettings.upColor || '#089981') : 'transparent';
        const wickDownColor = chartSettings.showCandleWicks ? (chartSettings.wickDownColor || chartSettings.downColor || (isDarkMode ? '#f23645' : '#131722')) : 'transparent';

        series2Ref.current.applyOptions({
          upColor,
          downColor,
          wickVisible: chartSettings.showCandleWicks,
          borderVisible: chartSettings.showCandleBorders,
          borderUpColor,
          borderDownColor,
          wickUpColor,
          wickDownColor,
        });
      } else if (chartType === 'bar') {
        const upColor = chartSettings.showCandleBody ? (chartSettings.upColor || '#089981') : 'transparent';
        const downColor = chartSettings.showCandleBody ? (chartSettings.downColor || (isDarkMode ? '#f23645' : '#131722')) : 'transparent';
        series2Ref.current.applyOptions({ upColor, downColor });
      } else if (chartType === 'line') {
        series2Ref.current.applyOptions({ color: themeColor });
      }
    }

    const data = chartType === 'line'
      ? displayBars.map(b => ({ time: b.time, value: b.close }))
      : displayBars;

    series2Ref.current.setData(data);

    if (volume2Ref.current) {
      volume2Ref.current.setData(displayBars.map(b => ({
        time: b.time,
        value: b.volume,
        color: b.close >= b.open ? 'rgba(8, 153, 129, 0.2)' : (isDarkMode ? 'rgba(242, 54, 69, 0.2)' : 'rgba(19, 23, 34, 0.2)')
      })));
    }
  };

  useEffect(() => {
    if (chart2Initialized && allBars2.length > 0) {
      updateChart2Data(allBars2);
    }
  }, [chart2Initialized, chartType, themeColor, isDarkMode, chartSettings, replayMode, replayIndex, allBars, allBars2]);

  useEffect(() => {
    if (volume2Ref.current) {
      volume2Ref.current.applyOptions({ visible: showVolume });
    }
  }, [showVolume]);

  // Sync state refs to callbacks
  const allBarsRef = useRef(allBars);
  allBarsRef.current = allBars;

  const [seriesUpdateTick, setSeriesUpdateTick] = useState(0);


  const currentTfRef = useRef(timeframe);
  currentTfRef.current = timeframe;

  // Ref to track which chart type is currently created
  const currentChartTypeRef = useRef(null);

  // --- REBUILD OR UPDATE SERIES ---
  const updateChartData = (bars) => {
    const chart = chartRef.current;
    if (!chart) return;

    // Filter bars if we are in replay mode or an active training session
    let displayBars = bars;
    if (replayMode) {
      if (currentBarStates && currentBarStates.length > 0 && currentSubStep < currentBarStates.length) {
        displayBars = [...bars.slice(0, replayIndex - 1), currentBarStates[currentSubStep]];
      } else {
        displayBars = bars.slice(0, replayIndex);
      }
    }

    // Only recreate series if chart type actually changed or doesn't exist
    if (!seriesRef.current || currentChartTypeRef.current !== chartType) {
      // Remove existing main series
      if (seriesRef.current) {
        try {
          chart.removeSeries(seriesRef.current);
        } catch (e) {}
      }

      // Add appropriate series
      const upColor = chartSettings.showCandleBody ? (chartSettings.upColor || '#089981') : 'transparent';
      const downColor = chartSettings.showCandleBody ? (chartSettings.downColor || (isDarkMode ? '#f23645' : '#131722')) : 'transparent';
      const borderUpColor = chartSettings.showCandleBorders ? (chartSettings.borderUpColor || chartSettings.upColor || '#089981') : 'transparent';
      const borderDownColor = chartSettings.showCandleBorders ? (chartSettings.borderDownColor || chartSettings.downColor || (isDarkMode ? '#f23645' : '#131722')) : 'transparent';
      const wickUpColor = chartSettings.showCandleWicks ? (chartSettings.wickUpColor || chartSettings.upColor || '#089981') : 'transparent';
      const wickDownColor = chartSettings.showCandleWicks ? (chartSettings.wickDownColor || chartSettings.downColor || (isDarkMode ? '#f23645' : '#131722')) : 'transparent';

      if (chartType === 'candle') {
        seriesRef.current = chart.addSeries(CandlestickSeries, {
          upColor: upColor,
          downColor: downColor,
          wickVisible: chartSettings.showCandleWicks,
          borderVisible: chartSettings.showCandleBorders,
          borderUpColor: borderUpColor,
          borderDownColor: borderDownColor,
          wickUpColor: wickUpColor,
          wickDownColor: wickDownColor,
        });
      } else if (chartType === 'bar') {
        seriesRef.current = chart.addSeries(BarSeries, {
          upColor: upColor,
          downColor: downColor,
        });
      } else {
        seriesRef.current = chart.addSeries(LineSeries, {
          color: themeColor,
          lineWidth: 2,
        });
      }

      currentChartTypeRef.current = chartType;
      // Force re-render so DrawingCanvas gets the new series reference
      setSeriesUpdateTick(t => t + 1);
    } else {
      // Apply options dynamically to existing series in-place
      if (chartType === 'candle') {
        const upColor = chartSettings.showCandleBody ? (chartSettings.upColor || '#089981') : 'transparent';
        const downColor = chartSettings.showCandleBody ? (chartSettings.downColor || (isDarkMode ? '#f23645' : '#131722')) : 'transparent';
        const borderUpColor = chartSettings.showCandleBorders ? (chartSettings.borderUpColor || chartSettings.upColor || '#089981') : 'transparent';
        const borderDownColor = chartSettings.showCandleBorders ? (chartSettings.borderDownColor || chartSettings.downColor || (isDarkMode ? '#f23645' : '#131722')) : 'transparent';
        const wickUpColor = chartSettings.showCandleWicks ? (chartSettings.wickUpColor || chartSettings.upColor || '#089981') : 'transparent';
        const wickDownColor = chartSettings.showCandleWicks ? (chartSettings.wickDownColor || chartSettings.downColor || (isDarkMode ? '#f23645' : '#131722')) : 'transparent';

        seriesRef.current.applyOptions({
          upColor: upColor,
          downColor: downColor,
          wickVisible: chartSettings.showCandleWicks,
          borderVisible: chartSettings.showCandleBorders,
          borderUpColor: borderUpColor,
          borderDownColor: borderDownColor,
          wickUpColor: wickUpColor,
          wickDownColor: wickDownColor,
        });
      } else if (chartType === 'bar') {
        const upColor = chartSettings.showCandleBody ? (chartSettings.upColor || '#089981') : 'transparent';
        const downColor = chartSettings.showCandleBody ? (chartSettings.downColor || (isDarkMode ? '#f23645' : '#131722')) : 'transparent';
        seriesRef.current.applyOptions({
          upColor: upColor,
          downColor: downColor,
        });
      } else if (chartType === 'line') {
        seriesRef.current.applyOptions({ color: themeColor });
      }
    }

    // Map and load bars data
    const data = chartType === 'line'
      ? displayBars.map(b => ({ time: b.time, value: b.close }))
      : displayBars;

    seriesRef.current.setData(data);

    // Map and load volume
    if (volumeRef.current) {
      volumeRef.current.setData(displayBars.map(b => ({
        time: b.time,
        value: b.volume,
        color: b.close >= b.open ? 'rgba(8, 153, 129, 0.2)' : (isDarkMode ? 'rgba(242, 54, 69, 0.2)' : 'rgba(19, 23, 34, 0.2)')
      })));
    }

    if (!replayMode) {
      if (displayBars.length > 300) {
        const didReset = checkAndResetViewportChange();
        if (didReset) {
          setTimeout(() => {
            if (chartRef.current && displayBars.length > 0) {
              const timeScale = chartRef.current.timeScale();
              timeScale.setVisibleRange({
                from: displayBars[Math.max(0, displayBars.length - 150)].time,
                to: displayBars[displayBars.length - 1].time
              });
            }
          }, 50);
        }
      } else {
        chart.timeScale().fitContent();
      }
    } else if (replayMode) {
      const timeScale = chart.timeScale();
      const didReset = checkAndResetViewportChange();

      if (didReset) {
        // Initial zoom and center on the replay start bar with right margins
        setTimeout(() => {
          if (chartRef.current && displayBars.length > 0) {
            // Force price auto-scale to ensure candles are visible vertically
            chartRef.current.priceScale('right').applyOptions({ autoScale: true });

            const curIndex = displayBars.length - 1;
            const width = 150; // show 150 bars
            const rightMargin = 30; // 30 blank bars lookahead
            chartRef.current.timeScale().setVisibleLogicalRange({
              from: curIndex - (width - rightMargin),
              to: curIndex + rightMargin
            });
          }
        }, 50);
      } else {
        // Step forward / play ticks: scroll ONLY when candle gets near the right edge
        const range = timeScale.getVisibleLogicalRange();
        if (range && displayBars.length > 0) {
          const curIndex = displayBars.length - 1;
          const rightMargin = 30; // keep 30 blank bars margin when scrolling
          if (curIndex > range.to - 5) {
            const width = range.to - range.from;
            const newTo = curIndex + rightMargin;
            timeScale.setVisibleLogicalRange({
              from: newTo - width,
              to: newTo
            });
          }
        }
      }
    }
  };

  useEffect(() => {
    if (chartInitialized && allBars.length > 0) {
      updateChartData(allBars);
    }
  }, [chartType, themeColor, isDarkMode, chartSettings, replayMode, replayIndex, allBars, currentSubStep, currentBarStates]);

  // Toggle volume series visibility
  useEffect(() => {
    if (volumeRef.current) {
      volumeRef.current.applyOptions({ visible: showVolume });
    }
  }, [showVolume]);

  // --- REPLAY CONTROLS ---
  const handleExitReplay = () => {
    localStorage.removeItem('tv_replay_mode');
    localStorage.removeItem('tv_last_replay_time');
    setReplayMode(false);
    setIsReplayPlaying(false);
    setReplayTimeOffset(null);
    lastReplayTimeRef.current = null;
    if (replayTimerRef.current) {
      clearInterval(replayTimerRef.current);
    }
    setTimeout(() => {
      if (chartRef.current) {
        chartRef.current.timeScale().fitContent();
      }
    }, 50);
  };

  const handleStartReplay = () => {
    if (allBars.length === 0) return;
    lastReplayTimeRef.current = null;
    localStorage.removeItem('tv_last_replay_time');
    forceViewportResetRef.current = true;
    setReplayMode(true);
    localStorage.setItem('tv_replay_mode', 'true');
    setIsReplayPlaying(false);

    // Pick a start point: try to use the center of the current visible range,
    // or fall back to 200 bars back from the end of the loaded dataset.
    let targetTime = null;
    if (chartRef.current && allBars.length > 0) {
      try {
        const range = chartRef.current.timeScale().getVisibleLogicalRange();
        if (range) {
          const midIdx = Math.round((range.from + range.to) / 2);
          const clampedIdx = Math.max(0, Math.min(allBars.length - 1, midIdx));
          targetTime = allBars[clampedIdx].time;
        }
      } catch (e) {}
    }
    if (!targetTime && allBars.length > 0) {
      const startIndex = Math.max(50, allBars.length - 200);
      targetTime = allBars[startIndex - 1].time;
    }

    // Setting replayTimeOffset triggers a windowed data reload (history behind target)
    setReplayTimeOffset(targetTime);
  };

  const toggleReplayPlay = () => {
    setIsReplayPlaying(prev => !prev);
  };

  const handleDateJump = (dateString) => {
    if (!dateString) return;
    const targetDate = new Date(dateString + 'T00:00:00');
    const targetSeconds = Math.floor(targetDate.getTime() / 1000);
    // Setting replayTimeOffset triggers a windowed data reload centered on this date.
    // The data-fetch effect will then find the correct bar and set replayIndex.
    setCurrentSubStep(0);
    forceViewportResetRef.current = true;
    setReplayTimeOffset(targetSeconds);
  };

  const currentReplayDateString = useMemo(() => {
    const currentBar = allBars[replayIndex - 1];
    if (!currentBar) return '';
    const d = new Date(currentBar.time * 1000);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }, [allBars, replayIndex]);

  const handleStepForward = () => {
    if (replayIndex >= allBars.length) return;

    const chartTfSec = timeframe * 60;
    const stepSec = getReplayStepSeconds(replayTimeframeOption);

    if (stepSec < chartTfSec) {
      // Sub-candle mode
      const N = Math.round(chartTfSec / stepSec);
      if (currentSubStep < N - 1) {
        setCurrentSubStep(currentSubStep + 1);
      } else {
        const next = replayIndex + 1;
        if (next <= allBars.length) {
          setReplayIndex(next);
          setCurrentSubStep(0);
          const nextBar = allBars[next - 1];
          if (nextBar) {
            const nextN = Math.round(chartTfSec / stepSec);
            setCurrentBarStates(generateSubCandleStates(nextBar, nextN));
          }
        }
      }
    } else {
      // Multi-bar step mode
      const K = Math.floor(stepSec / chartTfSec) || 1;
      setReplayIndex(Math.min(allBars.length, replayIndex + K));
      setCurrentSubStep(0);
      setCurrentBarStates([]);
    }
  };

  const handleStepBack = () => {
    const chartTfSec = timeframe * 60;
    const stepSec = getReplayStepSeconds(replayTimeframeOption);

    if (stepSec < chartTfSec) {
      // Sub-candle mode
      if (currentSubStep > 0) {
        setCurrentSubStep(prev => prev - 1);
      } else {
        if (replayIndex <= 1) return;
        const prevIdx = replayIndex - 1;
        setReplayIndex(prevIdx);
        const N = Math.round(chartTfSec / stepSec);
        setCurrentSubStep(N - 1);
        const prevBar = allBars[prevIdx - 1];
        if (prevBar) {
          const prevStates = generateSubCandleStates(prevBar, N);
          setCurrentBarStates(prevStates);
        }
      }
    } else {
      // Multi-bar step mode
      const K = Math.floor(stepSec / chartTfSec) || 1;
      setReplayIndex(prev => Math.max(1, prev - K));
      setCurrentSubStep(0);
      setCurrentBarStates([]);
    }
  };

  useEffect(() => {
    if (replayMode && isReplayPlaying) {
      replayTimerRef.current = setInterval(() => {
        handleStepForward();
      }, replaySpeed);
    } else {
      if (replayTimerRef.current) {
        clearInterval(replayTimerRef.current);
      }
    }
    return () => {
      if (replayTimerRef.current) {
        clearInterval(replayTimerRef.current);
      }
    };
  }, [replayMode, isReplayPlaying, replaySpeed, allBars, replayIndex, currentSubStep, replayTimeframeOption, timeframe, currentBarStates]);

  // --- REPLAY KEYBOARD SHORTCUTS ---
  useEffect(() => {
    const handleKeyDown = (e) => {
      const activeEl = document.activeElement;
      if (activeEl && (
        activeEl.tagName === 'INPUT' ||
        activeEl.tagName === 'TEXTAREA' ||
        activeEl.tagName === 'SELECT' ||
        activeEl.isContentEditable
      )) {
        return;
      }

      if (!replayMode) return;

      if (e.code === 'Space') {
        e.preventDefault();
        toggleReplayPlay();
      } else if (e.code === 'ArrowRight') {
        e.preventDefault();
        handleStepForward();
      } else if (e.code === 'ArrowLeft') {
        e.preventDefault();
        handleStepBack();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [replayMode, isReplayPlaying, allBars, replayIndex, currentSubStep, replayTimeframeOption, timeframe, currentBarStates]);

  // --- UNDO / REDO MANAGERS ---
  const handleAddUndoState = () => {
    setUndoStack([...undoStack, JSON.stringify(drawings)]);
    setRedoStack([]); // Clear redo
  };

  const handleUndo = () => {
    if (undoStack.length === 0) return;
    const previous = undoStack[undoStack.length - 1];
    setRedoStack([...redoStack, JSON.stringify(drawings)]);
    setDrawings(JSON.parse(previous));
    setUndoStack(undoStack.slice(0, -1));
    setSelectedDrawing(null);
  };

  const handleRedo = () => {
    if (redoStack.length === 0) return;
    const next = redoStack[redoStack.length - 1];
    setUndoStack([...undoStack, JSON.stringify(drawings)]);
    setDrawings(JSON.parse(next));
    setRedoStack(redoStack.slice(0, -1));
    setSelectedDrawing(null);
  };

  // Clear all drawings
  const handleClearAll = () => {
    handleAddUndoState();
    setDrawings([]);
    setSelectedDrawing(null);
  };

  // Sessions shading is handled internally inside the DrawingCanvas component

  // Quick Bottom Timeframe scaling
  const handleBottomTimeScale = (days) => {
    if (!chartRef.current || allBars.length === 0) return;
    const timeScale = chartRef.current.timeScale();
    
    // Zoom time scale to show only the last X days of bars
    const barDuration = timeframe * 60;
    const count = Math.round((days * 24 * 3600) / barDuration);
    
    const visibleRange = {
      from: Math.max(0, allBars.length - count),
      to: allBars.length - 1
    };
    timeScale.setVisibleRange({
      from: allBars[visibleRange.from].time,
      to: allBars[visibleRange.to].time
    });
  };

  // --- FLOATING CHART NAVIGATION HANDLERS ---
  const handleZoomIn = () => {
    if (!chartRef.current) return;
    const timeScale = chartRef.current.timeScale();
    const current = timeScale.options().barSpacing;
    timeScale.applyOptions({ barSpacing: Math.min(50, current * 1.05) });
  };

  const handleZoomOut = () => {
    if (!chartRef.current) return;
    const timeScale = chartRef.current.timeScale();
    const current = timeScale.options().barSpacing;
    timeScale.applyOptions({ barSpacing: Math.max(0.5, current * 0.95) });
  };

  const handleScrollLeft = () => {
    if (!chartRef.current) return;
    const timeScale = chartRef.current.timeScale();
    const range = timeScale.getVisibleLogicalRange();
    if (range) {
      const shift = Math.max(1, (range.to - range.from) * 0.05);
      timeScale.setVisibleLogicalRange({
        from: range.from - shift,
        to: range.to - shift
      });
    }
  };

  const handleScrollRight = () => {
    if (!chartRef.current) return;
    const timeScale = chartRef.current.timeScale();
    const range = timeScale.getVisibleLogicalRange();
    if (range) {
      const shift = Math.max(1, (range.to - range.from) * 0.05);
      timeScale.setVisibleLogicalRange({
        from: range.from + shift,
        to: range.to + shift
      });
    }
  };

  const handleResetScale = () => {
    if (!chartRef.current) return;
    chartRef.current.priceScale('right').applyOptions({ autoScale: true });
    if (replayMode) {
      chartRef.current.timeScale().scrollToRealTime();
    } else {
      chartRef.current.timeScale().resetTimeScale();
    }
  };

  return (
    <div className="app-container">
      {/* TOP TOOLBAR */}
      <header className="top-toolbar">
        <div className="logo" style={{ marginRight: '8px' }}>
          PDOS <span>MOS</span>
        </div>

        {/* WORKSPACE TAB SWITCHER */}
        <div className="workspace-tabs" style={{ display: 'flex', gap: '2px', background: '#1c2030', padding: '2px', borderRadius: '4px', border: '1px solid var(--border)', marginRight: '6px' }}>
          {[
            { id: 'chart', label: '📊 Chart' },
            { id: 'validation', label: '✔️ Validation' },
            { id: 'research', label: '🔍 Research' },
            { id: 'diagnostics', label: '⚙️ Diagnostics' }
          ].map(tab => (
            <button
              key={tab.id}
              className={`toolbar-btn ${workspaceTab === tab.id ? 'active' : ''}`}
              style={{
                padding: '4px 10px',
                fontSize: '11px',
                fontWeight: 600,
                borderRadius: '3px',
                cursor: 'pointer',
                border: 'none',
                background: workspaceTab === tab.id ? 'var(--accent)' : 'transparent',
                color: '#fff',
                transition: 'background 0.2s'
              }}
              onClick={() => setWorkspaceTab(tab.id)}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="divider" />

        {/* Symbol Select dropdown */}
        <select
          className="symbol-selector"
          value={activeSymbol}
          onChange={(e) => setActiveSymbol(e.target.value)}
        >
          {symbols.map(sym => (
            <option key={sym} value={sym}>{sym.toUpperCase()}</option>
          ))}
        </select>

        <div className="divider" />

        {/* Timeframe aggregation */}
        <div className="tf-group">
          {[
            { label: '1m', val: 1 },
            { label: '3m', val: 3 },
            { label: '5m', val: 5 },
            { label: '15m', val: 15 },
            { label: '30m', val: 30 },
            { label: '1H', val: 60 },
            { label: '4H', val: 240 },
            { label: '1D', val: 1440 }
          ].map(item => (
            <button
              key={item.label}
              className={`toolbar-btn ${timeframe === item.val ? 'active' : ''}`}
              onClick={() => setTimeframe(item.val)}
            >
              {item.label}
            </button>
          ))}
        </div>

        <div className="divider" />

        {/* Chart type selection */}
        <div className="tf-group">
          {[
            { label: 'Candles', val: 'candle' },
            { label: 'Bars', val: 'bar' },
            { label: 'Line', val: 'line' }
          ].map(item => (
            <button
              key={item.val}
              className={`toolbar-btn ${chartType === item.val ? 'active' : ''}`}
              onClick={() => setChartType(item.val)}
            >
              {item.label}
            </button>
          ))}
        </div>

        <div className="divider" />

        {/* Layout Select Toggle */}
        <button
          className={`toolbar-btn ${layout === 'split' ? 'active' : ''}`}
          onClick={() => setLayout(l => l === 'single' ? 'split' : 'single')}
          title="Toggle Split Screen Layout (Dual Timeframe)"
        >
          <Layers size={14} style={{ marginRight: '5px' }} />
          {layout === 'split' ? 'Split Layout' : 'Single Layout'}
        </button>

        {layout === 'split' && (
          <>
            <div className="divider" />
            <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
              <span style={{ fontSize: '11px', color: 'var(--text-muted)', fontWeight: 600 }}>TF2:</span>
              <select
                className="symbol-selector"
                style={{ padding: '3px 6px', fontSize: '11px', height: '26px', minWidth: '60px' }}
                value={timeframe2}
                onChange={(e) => setTimeframe2(Number(e.target.value))}
              >
                {[
                  { label: '1m', val: 1 },
                  { label: '3m', val: 3 },
                  { label: '5m', val: 5 },
                  { label: '15m', val: 15 },
                  { label: '30m', val: 30 },
                  { label: '1H', val: 60 },
                  { label: '4H', val: 240 },
                  { label: '1D', val: 1440 }
                ].map(item => (
                  <option key={item.val} value={item.val}>{item.label}</option>
                ))}
              </select>
            </div>
          </>
        )}

        <div className="divider" />

        {/* ICT Sessions Toggle */}
        <button
          className={`toolbar-btn ${showSessions ? 'active' : ''}`}
          onClick={() => setShowSessions(!showSessions)}
          title="Toggle Midnight/8:30 opens & Session highlights"
        >
          <Activity size={14} style={{ marginRight: '5px' }} />
          ICT Sessions
        </button>

        <div className="divider" />

        {/* Swings Toggle */}
        <button
          className={`toolbar-btn ${debugOverlayFilters.swings ? 'active' : ''}`}
          onClick={() => setDebugOverlayFilters(f => ({ ...f, swings: !f.swings }))}
          title="Toggle Swing pivot rendering (STH/ITH/LTH & STL/ITL/LTL)"
        >
          Swings
        </button>

        {/* Liquidity Toggle + taken-opacity slider */}
        <button
          className={`toolbar-btn ${debugOverlayFilters.liquidity ? 'active' : ''}`}
          onClick={() => setDebugOverlayFilters(f => ({ ...f, liquidity: !f.liquidity }))}
          title="Toggle Liquidity line rendering (BSL / SSL)"
        >
          Liquidity
        </button>

        {debugOverlayFilters.liquidity && (
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '5px',
              padding: '0 6px',
              borderLeft: '1px solid var(--border)'
            }}
            title="Opacity of taken (terminated) liquidity lines"
          >
            <span style={{ fontSize: '10px', color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>
              Taken
            </span>
            <input
              id="taken-liq-opacity-slider"
              type="range"
              min="0.25"
              max="0.70"
              step="0.05"
              value={debugOverlayFilters.takenLiqOpacity ?? 0.25}
              onChange={e =>
                setDebugOverlayFilters(f => ({ ...f, takenLiqOpacity: parseFloat(e.target.value) }))
              }
              className="opacity-slider"
            />
            <span style={{ fontSize: '10px', color: 'var(--text-muted)', minWidth: '26px', textAlign: 'right' }}>
              {Math.round((debugOverlayFilters.takenLiqOpacity ?? 0.25) * 100)}%
            </span>
          </div>
        )}

        {/* Volume Toggle */}
        <button
          className={`toolbar-btn ${showVolume ? 'active' : ''}`}
          onClick={() => setShowVolume(v => !v)}
          title="Toggle Volume"
        >
          <BarChart2 size={14} style={{ marginRight: '5px' }} />
          Volume
        </button>

        {/* Replay Toggle */}
        <button
          className={`toolbar-btn ${replayMode ? 'active' : ''}`}
          onClick={() => {
            if (replayMode) {
              handleExitReplay();
            } else {
              handleStartReplay();
            }
          }}
          title="Toggle Replay Mode"
        >
          <History size={14} style={{ marginRight: '5px' }} />
          Replay
        </button>

        {/* Undo / Redo */}
        <button
          className="toolbar-icon-btn"
          disabled={undoStack.length === 0}
          onClick={handleUndo}
          title="Undo (Ctrl+Z)"
        >
          <Undo2 size={14} style={{ opacity: undoStack.length === 0 ? 0.4 : 1 }} />
        </button>
        <button
          className="toolbar-icon-btn"
          disabled={redoStack.length === 0}
          onClick={handleRedo}
          title="Redo (Ctrl+Y)"
        >
          <Redo2 size={14} style={{ opacity: redoStack.length === 0 ? 0.4 : 1 }} />
        </button>

        {/* Settings button on the right */}
        <div style={{ marginLeft: 'auto', display: 'flex', gap: '4px' }}>
          <button 
            className="toolbar-icon-btn" 
            onClick={() => setIsDarkMode(v => !v)} 
            title={isDarkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
          >
            {isDarkMode ? <Sun size={14} /> : <Moon size={14} />}
          </button>
          {selectedConcept && (
            <button
              className={`toolbar-btn ${showAlgoZones ? 'active' : ''}`}
              style={{ padding: '5px 12px', fontSize: '12px', fontWeight: 600, marginRight: '4px' }}
              onClick={() => setShowAlgoZones(v => !v)}
              title="Toggle Auto-detected Candidate Zones on Chart"
            >
              Zones
            </button>
          )}
          {selectedConcept && selectedConcept.startsWith('liquidity') && (
            <select
              className="symbol-selector"
              style={{ padding: '5px 8px', fontSize: '12px', height: '28px', minWidth: '140px', marginRight: '6px' }}
              value={displayMode}
              onChange={(e) => setDisplayMode(e.target.value)}
              title="Liquidity Display Mode"
            >
              <option value="default">Default Mode</option>
              <option value="consolidated">Consolidated Only</option>
              <option value="research">Research Mode (All)</option>
            </select>
          )}
          <div className="segmented-control" style={{ display: 'flex', background: '#1c2030', border: '1px solid #2a2e39', borderRadius: '4px', padding: '2px', marginRight: '6px', height: '28px', boxSizing: 'border-box' }}>
            <button
              className={`segmented-btn ${viewMode === 'narrative' ? 'active' : ''}`}
              style={{
                background: viewMode === 'narrative' ? 'var(--accent)' : 'none',
                border: 'none',
                color: '#ffffff',
                fontSize: '11px',
                fontWeight: 600,
                padding: '0 10px',
                borderRadius: '3px',
                cursor: 'pointer',
                height: '100%',
                transition: 'background 0.2s'
              }}
              onClick={() => {
                setViewMode('narrative');
                setNarrativeMode(true);
                setShowAlgoZones(true);
              }}
            >
              Narrative
            </button>
            <button
              className={`segmented-btn ${viewMode === 'analysis' ? 'active' : ''}`}
              style={{
                background: viewMode === 'analysis' ? 'var(--accent)' : 'none',
                border: 'none',
                color: '#ffffff',
                fontSize: '11px',
                fontWeight: 600,
                padding: '0 10px',
                borderRadius: '3px',
                cursor: 'pointer',
                height: '100%',
                transition: 'background 0.2s'
              }}
              onClick={() => {
                setViewMode('analysis');
                setNarrativeMode(false);
                setShowAlgoZones(true);
              }}
            >
              Analysis
            </button>
            <button
              className={`segmented-btn ${viewMode === 'debug' ? 'active' : ''}`}
              style={{
                background: viewMode === 'debug' ? '#ff9100' : 'none',
                border: 'none',
                color: '#ffffff',
                fontSize: '11px',
                fontWeight: 600,
                padding: '0 10px',
                borderRadius: '3px',
                cursor: 'pointer',
                height: '100%',
                transition: 'background 0.2s'
              }}
              onClick={() => {
                setViewMode('debug');
                setNarrativeMode(false);
                setShowAlgoZones(true);
              }}
            >
              Debug
            </button>
          </div>

          {viewMode === 'analysis' && (
            <div style={{ position: 'relative', marginRight: '6px' }}>
              <button
                className="toolbar-btn"
                style={{
                  height: '28px',
                  padding: '0 10px',
                  fontSize: '12px',
                  fontWeight: 600,
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px',
                  background: '#1c2030',
                  border: '1px solid #2a2e39',
                  color: '#ffb74d',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
                onClick={() => setIsLayersDropdownOpen(!isLayersDropdownOpen)}
              >
                <span>Layers</span>
                <span style={{ fontSize: '9px' }}>{isLayersDropdownOpen ? '▲' : '▼'}</span>
              </button>
              
              {isLayersDropdownOpen && (
                <div
                  style={{
                    position: 'absolute',
                    top: '32px',
                    right: 0,
                    background: '#0f1115',
                    border: '1px solid #2a2e39',
                    borderRadius: '4px',
                    boxShadow: '0 6px 16px rgba(0,0,0,0.85)',
                    zIndex: 1010,
                    padding: '10px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '8px',
                    minWidth: '140px'
                  }}
                >
                  {[
                    { key: 'swings', label: 'Swings' },
                    { key: 'liquidity', label: 'Liquidity' },
                    { key: 'structure', label: 'Structure' },
                    { key: 'dealingRanges', label: 'Dealing Ranges' },
                    { key: 'intent', label: 'Intent' },
                    { key: 'delivery', label: 'Delivery' }
                  ].map(item => (
                    <label key={item.key} style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '11px', color: '#b2b5be', cursor: 'pointer', userSelect: 'none' }}>
                      <input
                        type="checkbox"
                        checked={analysisLayers[item.key]}
                        onChange={(e) => {
                          setAnalysisLayers(prev => ({
                            ...prev,
                            [item.key]: e.target.checked
                          }));
                        }}
                        style={{ accentColor: 'var(--accent)', cursor: 'pointer' }}
                      />
                      {item.label}
                    </label>
                  ))}
                </div>
              )}
            </div>
          )}
          <button className="toolbar-icon-btn" onClick={() => setIsSettingsOpen(true)} title="Chart Settings">
            <Settings size={14} />
          </button>
          <button className="btn-primary" style={{ padding: '6px 14px', fontSize: '12px' }}>
            Publish
          </button>
        </div>
      </header>

      {/* MAIN CONTAINER */}
      <div className="main-content" style={{ display: 'flex', flex: 1, overflow: 'hidden', position: 'relative' }}>
        <div style={{ display: workspaceTab === 'chart' ? 'flex' : 'none', flex: 1, height: '100%', width: '100%', overflow: 'hidden' }}>
            {/* LEFT DRAWING SIDEBAR */}
            <aside className="drawing-sidebar">
              <button
                className={`sidebar-btn ${activeTool === null ? 'active' : ''}`}
                onClick={() => setActiveTool(null)}
                data-tooltip="Cursor"
              >
                <MousePointer size={16} />
              </button>

              <button
                className={`sidebar-btn ${activeTool === 'trendline' ? 'active' : ''}`}
                onClick={() => setActiveTool('trendline')}
                data-tooltip="Trend Line"
              >
                <TrendingUp size={16} />
              </button>

              <button
                className={`sidebar-btn ${activeTool === 'horizontal-line' ? 'active' : ''}`}
                onClick={() => setActiveTool('horizontal-line')}
                data-tooltip="Horizontal Line"
              >
                <Minus size={16} />
              </button>

              <button
                className={`sidebar-btn ${activeTool === 'ray' ? 'active' : ''}`}
                onClick={() => setActiveTool('ray')}
                data-tooltip="Horizontal Ray"
              >
                <ArrowUpRight size={16} />
              </button>

              <button
                className={`sidebar-btn ${activeTool === 'fibonacci' ? 'active' : ''}`}
                onClick={() => setActiveTool('fibonacci')}
                data-tooltip="Fibonacci Retracement"
              >
                <Layers size={16} />
              </button>

              <button
                className={`sidebar-btn ${activeTool === 'text' ? 'active' : ''}`}
                onClick={() => setActiveTool('text')}
                data-tooltip="Text Annotation"
              >
                <Type size={16} />
              </button>

              <button
                className={`sidebar-btn ${activeTool === 'brush' ? 'active' : ''}`}
                onClick={() => setActiveTool('brush')}
                data-tooltip="Brush (Freehand)"
              >
                <Brush size={16} />
              </button>

              <button
                className={`sidebar-btn ${activeTool === 'rectangle' ? 'active' : ''}`}
                onClick={() => setActiveTool('rectangle')}
                data-tooltip="Rectangle Shape"
              >
                <Square size={16} />
              </button>

              <button
                className={`sidebar-btn ${activeTool === 'position-long' ? 'active' : ''}`}
                onClick={() => setActiveTool('position-long')}
                data-tooltip="Long Position"
              >
                <TrendingUp size={16} style={{ color: '#089981' }} />
              </button>

              <button
                className={`sidebar-btn ${activeTool === 'position-short' ? 'active' : ''}`}
                onClick={() => setActiveTool('position-short')}
                data-tooltip="Short Position"
              >
                <TrendingDown size={16} style={{ color: '#f23645' }} />
              </button>

              <button
                className={`sidebar-btn ${activeTool === 'ruler' ? 'active' : ''}`}
                onClick={() => setActiveTool('ruler')}
                data-tooltip="Ruler (Measure)"
              >
                <Compass size={16} />
              </button>

              <div className="divider" style={{ width: '20px', height: '1px', margin: '6px 0' }} />

              {/* Magnet toggle */}
              <button
                className={`sidebar-btn ${magnetMode ? 'magnet-active' : ''}`}
                onClick={() => setMagnetMode(!magnetMode)}
                data-tooltip={magnetMode ? "Disable Magnet Mode" : "Enable Magnet Mode (Snaps to High/Low)"}
              >
                <Magnet size={16} style={{ color: magnetMode ? '#00e5ff' : 'inherit' }} />
              </button>

              {/* Lock all toggle */}
              <button
                className={`sidebar-btn ${lockDrawings ? 'lock-active' : ''}`}
                onClick={() => setLockDrawings(!lockDrawings)}
                data-tooltip={lockDrawings ? "Unlock all drawings" : "Lock all drawings"}
              >
                {lockDrawings ? <Lock size={16} style={{ color: '#ff9100' }} /> : <Unlock size={16} />}
              </button>

              {/* Hide/Show drawings */}
              <button
                className="sidebar-btn"
                onClick={() => setHideDrawings(!hideDrawings)}
                data-tooltip={hideDrawings ? "Show all drawings" : "Hide all drawings"}
              >
                {hideDrawings ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>

              {/* Clear all drawings */}
              <button
                className="sidebar-btn"
                onClick={handleClearAll}
                data-tooltip="Remove all drawings"
              >
                <Trash2 size={16} />
              </button>
            </aside>

            <ChartViewport 
              containerRef={containerRef}
              chartTargetRef={chartTargetRef}
              container2Ref={container2Ref}
              chartTarget2Ref={chartTarget2Ref}
              chartInitialized={chartInitialized}
              chart2Initialized={chart2Initialized}
              chartRef={chartRef}
              seriesRef={seriesRef}
              chart2Ref={chart2Ref}
              series2Ref={series2Ref}
              chartSettings={chartSettings}
              isDarkMode={isDarkMode}
              layout={layout}
              showVolume={showVolume}
              showSessions={showSessions}
              activeSymbol={activeSymbol}
              timeframe={timeframe}
              timeframe2={timeframe2}
              allBars={allBars}
              allBars2={allBars2}
              hudBar={hudBar}
              activeTool={activeTool}
              setActiveTool={setActiveTool}
              drawings={drawings}
              setDrawings={setDrawings}
              selectedDrawing={selectedDrawing}
              setSelectedDrawing={setSelectedDrawing}
              magnetMode={magnetMode}
              lockDrawings={lockDrawings}
              hideDrawings={hideDrawings}
              handleAddUndoState={handleAddUndoState}
              floatingToolbarPos={floatingToolbarPos}
              setFloatingToolbarPos={setFloatingToolbarPos}
              isToolbarPinned={isToolbarPinned}
              setIsToolbarPinned={setIsToolbarPinned}
              defaultToolStyles={defaultToolStyles}
              isDrawingSettingsOpen={isDrawingSettingsOpen}
              setIsDrawingSettingsOpen={setIsDrawingSettingsOpen}
              showAlgoZones={showAlgoZones}
              algoCandidates={filteredAlgoCandidates}
              algoCandidates2={filteredAlgoCandidates2}
              loadingState1={loadingState1}
              loadingState2={loadingState2}
              selectedConcept={selectedConcept}
              selectedAlgoCandidate={selectedAlgoCandidate}
              setSelectedAlgoCandidate={setSelectedAlgoCandidate}
              narrativeMode={narrativeMode}
              debugOverlayFilters={debugOverlayFilters}
              debugMode={viewMode === 'debug'}
              narrativeFocusRangeId={narrativeFocusRangeId}
              setNarrativeFocusRangeId={setNarrativeFocusRangeId}
              viewMode={viewMode}
              analysisLayers={analysisLayers}
              replayMode={replayMode}
              replayIndex={replayIndex}
              setReplayIndex={setReplayIndex}
              replaySpeed={replaySpeed}
              setReplaySpeed={setReplaySpeed}
              isReplayPlaying={isReplayPlaying}
              toggleReplayPlay={toggleReplayPlay}
              replayToolbarPos={replayToolbarPos}
              handleReplayDragStart={handleReplayDragStart}
              currentSubStep={currentSubStep}
              setCurrentSubStep={setCurrentSubStep}
              replayTimeframeOption={replayTimeframeOption}
              setReplayTimeframeOption={setReplayTimeframeOption}
              isTimeframeDropdownOpen={isTimeframeDropdownOpen}
              setIsTimeframeDropdownOpen={setIsTimeframeDropdownOpen}
              currentReplayDateString={currentReplayDateString}
              handleDateJump={handleDateJump}
              handleStepForward={handleStepForward}
              handleStepBack={handleStepBack}
              handleExitReplay={handleExitReplay}

              startContinuousAction={startContinuousAction}
              handleZoomIn={handleZoomIn}
              handleZoomOut={handleZoomOut}
              handleScrollLeft={handleScrollLeft}
              handleScrollRight={handleScrollRight}
              handleResetScale={handleResetScale}
              saveExplorerLabel={saveExplorerLabel}
            />

            <WatchlistSidebar 
              rightSidebarTab={rightSidebarTab}
              setRightSidebarTab={setRightSidebarTab}
              symbols={symbols}
              activeSymbol={activeSymbol}
              setActiveSymbol={setActiveSymbol}
              drawings={drawings}
              setDrawings={setDrawings}
              allBars={allBars}
              replayIndex={replayIndex}
              replayMode={replayMode}
              selectedAlgoCandidate={selectedAlgoCandidate}
              setSelectedAlgoCandidate={setSelectedAlgoCandidate}
              onSaveValidation={saveExplorerLabel}
              onJumpToTime={handleJumpToTime}
              debugMode={viewMode === 'debug'}
              debugOverlayFilters={debugOverlayFilters}
              setDebugOverlayFilters={setDebugOverlayFilters}
              narrativeMode={narrativeMode}
              setNarrativeMode={setNarrativeMode}
              narrativeFocusRangeId={narrativeFocusRangeId}
              setNarrativeFocusRangeId={setNarrativeFocusRangeId}
              algoCandidates={algoCandidates}
              viewMode={viewMode}
              setViewMode={setViewMode}
              analysisLayers={analysisLayers}
              setAnalysisLayers={setAnalysisLayers}
            />
          </div>

        {workspaceTab === 'validation' && (
          <ValidationWorkspace
            activeSymbol={activeSymbol}
            onSelectEvent={(ev) => {
              setSelectedAlgoCandidate(ev);
              setWorkspaceTab('chart');
              setRightSidebarTab('market');
            }}
            onJumpToTime={handleJumpToTime}
            onSwitchTab={setWorkspaceTab}
          />
        )}

        {workspaceTab === 'research' && (
          <ResearchWorkspace
            activeSymbol={activeSymbol}
            onSelectEvent={(ev) => {
              setSelectedAlgoCandidate(ev);
              setWorkspaceTab('chart');
              setRightSidebarTab('market');
            }}
            onJumpToTime={handleJumpToTime}
            onSwitchTab={setWorkspaceTab}
          />
        )}

        {workspaceTab === 'diagnostics' && (
          <DiagnosticsWorkspace activeSymbol={activeSymbol} />
        )}
      </div>

      {/* BOTTOM STATUS BAR */}
      <footer className="bottom-bar">
        <div className="bottom-left-group">
          <span>Time Scale:</span>
          <button className="bottom-tf-btn" onClick={() => handleBottomTimeScale(1)}>1D</button>
          <button className="bottom-tf-btn" onClick={() => handleBottomTimeScale(5)}>5D</button>
          <button className="bottom-tf-btn" onClick={() => handleBottomTimeScale(30)}>1M</button>
          <button className="bottom-tf-btn" onClick={() => handleBottomTimeScale(90)}>3M</button>
          <button className="bottom-tf-btn" onClick={() => handleBottomTimeScale(180)}>6M</button>
          <button className="bottom-tf-btn" onClick={() => handleBottomTimeScale(365)}>1Y</button>
          <button className="bottom-tf-btn" onClick={() => chartRef.current?.timeScale().fitContent()}>All</button>
        </div>
        <div className="bottom-right-group">
          <span>Timezone: America/New_York (EST)</span>
          <div className="status-indicator">
            <span className="status-dot" />
            <span>Local Database Connected</span>
          </div>
        </div>
      </footer>

      {/* SETTINGS MODAL */}
      {isSettingsOpen && (
        <ChartSettingsModal 
          onClose={() => setIsSettingsOpen(false)}
          chartSettings={chartSettings}
          setChartSettings={setChartSettings}
          themeColor={themeColor}
          setThemeColor={setThemeColor}
          showSessions={showSessions}
          setShowSessions={setShowSessions}
          magnetMode={magnetMode}
          setMagnetMode={setMagnetMode}
          isDarkMode={isDarkMode}
        />
      )}


    </div>
  );
}
