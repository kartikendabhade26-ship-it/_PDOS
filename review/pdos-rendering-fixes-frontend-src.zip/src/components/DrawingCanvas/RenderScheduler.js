/**
 * RenderScheduler.js
 * Coalesces rendering requests from multiple sources into a single requestAnimationFrame render pass.
 * Marks canvas layers as dirty and handles execution.
 *
 * Rev 2 changes (rendering-layer hardening, no market-logic impact):
 *   - Tracks the rAF handle so it can be cancelled on destroy(). Prevents stale
 *     render passes against detached canvases after the component unmounts.
 *   - Adds a preRender hook so per-frame state updates (replay terminations,
 *     narrative context) run exactly once per frame instead of once per layer.
 */
export default class RenderScheduler {
  constructor(layerManager) {
    this.layerManager = layerManager;
    this.scheduled = false;
    this.rafId = null;
    this.preRenderFns = [];
  }

  /**
   * Register a function to run once at the start of each scheduled frame,
   * before any dirty layer is rendered. Use this for per-frame state updates
   * that would otherwise be redundantly invoked by each layer's renderFn.
   * Returns an unsubscribe function.
   */
  addPreRender(fn) {
    this.preRenderFns.push(fn);
    return () => {
      const i = this.preRenderFns.indexOf(fn);
      if (i >= 0) this.preRenderFns.splice(i, 1);
    };
  }

  markDirty(layerName) {
    this.layerManager.setDirty(layerName, true);
    this.schedule();
  }

  markAllDirty() {
    this.layerManager.setAllDirty();
    this.schedule();
  }

  schedule() {
    if (this.scheduled) return;
    this.scheduled = true;
    this.rafId = requestAnimationFrame(() => {
      this.scheduled = false;
      this.rafId = null;
      // Run pre-render hooks once per frame (exceptions swallowed so a single
      // bad hook cannot block the render pipeline).
      for (let i = 0; i < this.preRenderFns.length; i++) {
        try { this.preRenderFns[i](); } catch (e) { /* swallow */ }
      }
      this.layerManager.renderDirty();
    });
  }

  /**
   * Cancel any pending rAF and detach preRender hooks.
   * Call this on component unmount to prevent stale renders.
   */
  destroy() {
    if (this.rafId != null) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
    this.scheduled = false;
    this.preRenderFns = [];
  }
}
